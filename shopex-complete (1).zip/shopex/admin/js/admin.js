// ============================================================
// SHOPEX ADMIN — Dashboard JavaScript
// ============================================================

const Admin = {
  currentSection: null,

  init() {
    this.checkAuth();
    this.router();
    this.renderSidebar();
    this.updateTopbar();
    window.addEventListener('hashchange', () => this.router());
  },

  checkAuth() {
    // If we're on the login page hash, allow it
    if (location.hash === '#admin-login' || location.hash === '') return;
    const user = DB.Session.get();
    if (!user || user.role !== 'admin') {
      location.hash = '#admin-login';
    }
  },

  router() {
    const hash = location.hash || '#admin-dashboard';
    const section = hash.replace('#admin-', '') || 'dashboard';

    // Show/hide login page
    if (section === 'login') {
      document.getElementById('admin-login-page').style.display = 'flex';
      document.getElementById('admin-app').style.display = 'none';
      Sections.login();
      return;
    }

    const user = DB.Session.get();
    if (!user || user.role !== 'admin') {
      location.hash = '#admin-login'; return;
    }

    document.getElementById('admin-login-page').style.display = 'none';
    document.getElementById('admin-app').style.display = 'flex';

    // Activate sidebar link
    document.querySelectorAll('.sidebar-link').forEach(l => {
      l.classList.toggle('active', l.dataset.section === section);
    });

    // Update topbar title
    const titles = {
      dashboard: 'Dashboard', products: 'Products', categories: 'Categories',
      orders: 'Orders', users: 'Users', settings: 'Settings'
    };
    document.getElementById('topbar-title').textContent = titles[section] || 'Dashboard';

    // Show section
    document.querySelectorAll('.admin-section').forEach(s => s.style.display = 'none');
    const target = document.getElementById('section-' + section);
    if (target) target.style.display = 'block';

    // Load section
    this.currentSection = section;
    Sections[section] && Sections[section]();
  },

  renderSidebar() {
    const user = DB.Session.get();
    if (!user) return;
    const initials = user.name.split(' ').map(n => n[0]).join('').toUpperCase();
    document.getElementById('sidebar-user-avatar') && (document.getElementById('sidebar-user-avatar').textContent = initials);
    document.getElementById('sidebar-user-name') && (document.getElementById('sidebar-user-name').textContent = user.name);
  },

  updateTopbar() {},

  logout() {
    DB.Session.clear();
    location.hash = '#admin-login';
  },

  toast(msg, type='') {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const t = document.createElement('div');
    t.className = `toast ${type}`;
    const icons = { success:'✓', error:'✕', warning:'⚠' };
    t.innerHTML = `<span>${icons[type] || 'ℹ'}</span> ${msg}`;
    container.appendChild(t);
    setTimeout(() => t.remove(), 3500);
  },

  formatCurrency(n) { return '$' + parseFloat(n||0).toFixed(2); },
  formatDate(iso) { return new Date(iso).toLocaleDateString('en-US', { year:'numeric', month:'short', day:'numeric' }); },

  confirm(msg, cb) {
    if (window.confirm(msg)) cb();
  },

  openModal(id) { document.getElementById(id)?.classList.add('open'); },
  closeModal(id) { document.getElementById(id)?.classList.remove('open'); },
};

// ============================================================
// SECTION CONTROLLERS
// ============================================================
const Sections = {

  login() {
    const form = document.getElementById('admin-login-form');
    if (form) form.onsubmit = (e) => {
      e.preventDefault();
      const email = document.getElementById('admin-email').value;
      const password = document.getElementById('admin-password').value;
      const user = DB.Users.authenticate(email, password);
      if (user && user.role === 'admin') {
        DB.Session.set(user);
        Admin.renderSidebar();
        location.hash = '#admin-dashboard';
      } else {
        Admin.toast('Invalid credentials or not an admin', 'error');
      }
    };
  },

  dashboard() {
    const products = DB.Products.all();
    const orders   = DB.Orders.all();
    const users    = DB.Users.all().filter(u => u.role === 'customer');
    const stats    = DB.Orders.stats();

    // Stat cards
    document.getElementById('stat-revenue')  && (document.getElementById('stat-revenue').textContent  = Admin.formatCurrency(stats.total));
    document.getElementById('stat-orders')   && (document.getElementById('stat-orders').textContent   = orders.length);
    document.getElementById('stat-products') && (document.getElementById('stat-products').textContent = products.length);
    document.getElementById('stat-customers')&& (document.getElementById('stat-customers').textContent= users.length);

    // Sales chart
    const monthly = stats.monthly;
    const labels = Object.keys(monthly);
    const values = Object.values(monthly);
    const max = Math.max(...values) || 1;

    const chartEl = document.getElementById('sales-chart');
    if (chartEl) chartEl.innerHTML = labels.map((label, i) => `
      <div class="chart-bar-group">
        <div class="chart-bar" style="height:${Math.max(4, (values[i]/max)*120)}px" title="${label}: ${Admin.formatCurrency(values[i])}"></div>
        <span class="chart-label">${label}</span>
      </div>`).join('');

    // Recent orders
    const recentOrders = [...orders].sort((a,b) => new Date(b.created_at) - new Date(a.created_at)).slice(0, 5);
    const recentEl = document.getElementById('recent-orders-table');
    if (recentEl) recentEl.innerHTML = recentOrders.length ? recentOrders.map(o => `
      <tr>
        <td><strong>#${o.id}</strong></td>
        <td>${o.user_name}</td>
        <td>${o.items.length} item${o.items.length !== 1 ? 's' : ''}</td>
        <td><strong>${Admin.formatCurrency(o.total)}</strong></td>
        <td><span class="badge badge-${Sections._orderBadge(o.status)}">${o.status}</span></td>
        <td>${Admin.formatDate(o.created_at)}</td>
      </tr>`).join('') : '<tr><td colspan="6" class="empty-state"><div class="empty-icon">📦</div><h4>No orders yet</h4></td></tr>';

    // Top products
    const topProductsEl = document.getElementById('top-products-list');
    if (topProductsEl) {
      const top = products.sort((a,b) => b.reviews - a.reviews).slice(0,5);
      topProductsEl.innerHTML = top.map(p => `
        <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border)">
          <img src="${p.images[0]}" class="product-thumb" onerror="this.src='https://via.placeholder.com/44'">
          <div style="flex:1;min-width:0">
            <div style="font-size:0.875rem;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${p.name}</div>
            <div style="font-size:0.75rem;color:var(--text-3)">${p.reviews} reviews · $${p.price}</div>
          </div>
          <div style="font-size:0.85rem;font-weight:700">${p.stock} left</div>
        </div>`).join('');
    }

    // Order status donut labels
    const statusEl = document.getElementById('status-breakdown');
    if (statusEl) {
      const sb = stats.byStatus;
      statusEl.innerHTML = Object.entries(sb).map(([s, c]) => `
        <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border)">
          <span class="badge badge-${Sections._orderBadge(s)}">${s}</span>
          <strong>${c}</strong>
        </div>`).join('');
    }
  },

  _orderBadge(status) {
    return { pending:'warning', processing:'info', shipped:'purple', delivered:'success', cancelled:'danger' }[status] || 'gray';
  },

  // ---- PRODUCTS ----
  products() {
    this._renderProducts(DB.Products.all());

    // Search
    const searchEl = document.getElementById('products-search');
    if (searchEl) searchEl.oninput = () => {
      const q = searchEl.value.toLowerCase();
      const filtered = DB.Products.all().filter(p => p.name.toLowerCase().includes(q));
      Sections._renderProducts(filtered);
    };

    // Category filter
    const catSel = document.getElementById('products-cat-filter');
    if (catSel) {
      const cats = DB.Categories.all();
      catSel.innerHTML = `<option value="">All Categories</option>` +
        cats.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
      catSel.onchange = () => {
        const val = catSel.value;
        const filtered = val ? DB.Products.byCategory(val) : DB.Products.all();
        Sections._renderProducts(filtered);
      };
    }

    // Add product
    document.getElementById('add-product-btn') && (document.getElementById('add-product-btn').onclick = () => {
      Sections._openProductModal(null);
    });
  },

  _renderProducts(products) {
    const el = document.getElementById('products-table-body');
    if (!el) return;
    if (!products.length) {
      el.innerHTML = `<tr><td colspan="7"><div class="empty-state"><div class="empty-icon">📦</div><h4>No products found</h4></div></td></tr>`;
      return;
    }
    el.innerHTML = products.map(p => {
      const cat = DB.Categories.find(p.category_id);
      const discount = p.original_price ? Math.round((1 - p.price/p.original_price)*100) : 0;
      return `<tr>
        <td><img src="${p.images[0]}" class="product-thumb" onerror="this.src='https://via.placeholder.com/44'"></td>
        <td>
          <div style="font-weight:600">${p.name}</div>
          <div style="font-size:0.75rem;color:var(--text-3)">${(p.description||'').substring(0,60)}…</div>
        </td>
        <td><span class="badge badge-info">${cat?.name || '—'}</span></td>
        <td>
          <div style="font-weight:700">${Admin.formatCurrency(p.price)}</div>
          ${discount > 0 ? `<div style="font-size:0.75rem;color:var(--danger)">-${discount}% off</div>` : ''}
        </td>
        <td>
          <span class="badge ${p.stock > 10 ? 'badge-success' : p.stock > 0 ? 'badge-warning' : 'badge-danger'}">${p.stock} in stock</span>
        </td>
        <td>
          <div style="display:flex;align-items:center;gap:4px">
            <span style="color:#f59e0b">★</span> ${p.rating} (${p.reviews})
          </div>
        </td>
        <td>
          <div class="actions">
            <button class="btn btn-ghost btn-sm btn-icon" onclick="Sections._openProductModal(${p.id})" title="Edit">✏️</button>
            <button class="btn btn-danger btn-sm btn-icon" onclick="Sections._deleteProduct(${p.id})" title="Delete">🗑️</button>
          </div>
        </td>
      </tr>`;
    }).join('');
  },

  _openProductModal(id) {
    const isEdit = id !== null;
    const p = isEdit ? DB.Products.find(id) : null;
    const cats = DB.Categories.all();

    document.getElementById('product-modal-title').textContent = isEdit ? 'Edit Product' : 'Add New Product';
    document.getElementById('product-modal-id').value = id || '';
    document.getElementById('pm-name').value = p?.name || '';
    document.getElementById('pm-price').value = p?.price || '';
    document.getElementById('pm-original-price').value = p?.original_price || '';
    document.getElementById('pm-stock').value = p?.stock || '';
    document.getElementById('pm-badge').value = p?.badge || '';
    document.getElementById('pm-desc').value = p?.description || '';
    document.getElementById('pm-featured').checked = p?.featured || false;
    document.getElementById('pm-rating').value = p?.rating || '4.5';
    document.getElementById('pm-reviews').value = p?.reviews || '0';
    document.getElementById('pm-images').value = (p?.images || []).join('\n');

    const catSel = document.getElementById('pm-category');
    catSel.innerHTML = cats.map(c => `<option value="${c.id}" ${p?.category_id == c.id ? 'selected' : ''}>${c.name}</option>`).join('');

    // Preview images
    Sections._updateImgPreviews();

    Admin.openModal('product-modal');
  },

  _updateImgPreviews() {
    const urls = document.getElementById('pm-images')?.value.split('\n').map(s => s.trim()).filter(Boolean) || [];
    const previewEl = document.getElementById('pm-img-previews');
    if (previewEl) previewEl.innerHTML = urls.map((url, i) => `
      <div class="img-preview">
        <img src="${url}" onerror="this.src='https://via.placeholder.com/80?text=Error'">
      </div>`).join('');
  },

  _saveProduct() {
    const id = document.getElementById('product-modal-id').value;
    const data = {
      name: document.getElementById('pm-name').value,
      category_id: parseInt(document.getElementById('pm-category').value),
      price: parseFloat(document.getElementById('pm-price').value),
      original_price: parseFloat(document.getElementById('pm-original-price').value) || null,
      stock: parseInt(document.getElementById('pm-stock').value),
      badge: document.getElementById('pm-badge').value,
      description: document.getElementById('pm-desc').value,
      featured: document.getElementById('pm-featured').checked,
      rating: parseFloat(document.getElementById('pm-rating').value),
      reviews: parseInt(document.getElementById('pm-reviews').value),
      images: document.getElementById('pm-images').value.split('\n').map(s => s.trim()).filter(Boolean),
    };

    if (!data.name || !data.price || !data.images.length) {
      Admin.toast('Please fill in all required fields', 'error'); return;
    }

    if (id) {
      DB.Products.update(id, data);
      Admin.toast('Product updated successfully!', 'success');
    } else {
      DB.Products.create(data);
      Admin.toast('Product created successfully!', 'success');
    }

    Admin.closeModal('product-modal');
    Sections._renderProducts(DB.Products.all());
  },

  _deleteProduct(id) {
    Admin.confirm('Are you sure you want to delete this product?', () => {
      DB.Products.delete(id);
      Admin.toast('Product deleted', 'warning');
      Sections._renderProducts(DB.Products.all());
    });
  },

  // ---- CATEGORIES ----
  categories() {
    this._renderCategories();
    document.getElementById('add-cat-btn') && (document.getElementById('add-cat-btn').onclick = () => Sections._openCatModal(null));
  },

  _renderCategories() {
    const el = document.getElementById('categories-table-body');
    if (!el) return;
    const cats = DB.Categories.all();
    el.innerHTML = cats.length ? cats.map(c => {
      const count = DB.Products.byCategory(c.id).length;
      return `<tr>
        <td><div style="font-size:1.5rem">${c.icon}</div></td>
        <td><div style="font-weight:600">${c.name}</div><div style="font-size:0.75rem;color:var(--text-3)">${c.slug}</div></td>
        <td>${c.description || '—'}</td>
        <td><span class="badge badge-info">${count} products</span></td>
        <td>
          <div class="actions">
            <button class="btn btn-ghost btn-sm btn-icon" onclick="Sections._openCatModal(${c.id})">✏️</button>
            <button class="btn btn-danger btn-sm btn-icon" onclick="Sections._deleteCat(${c.id})">🗑️</button>
          </div>
        </td>
      </tr>`;
    }).join('') : `<tr><td colspan="5"><div class="empty-state"><div class="empty-icon">📂</div><h4>No categories yet</h4></div></td></tr>`;
  },

  _openCatModal(id) {
    const c = id ? DB.Categories.find(id) : null;
    document.getElementById('cat-modal-title').textContent = id ? 'Edit Category' : 'Add Category';
    document.getElementById('cat-modal-id').value = id || '';
    document.getElementById('cm-name').value = c?.name || '';
    document.getElementById('cm-slug').value = c?.slug || '';
    document.getElementById('cm-icon').value = c?.icon || '';
    document.getElementById('cm-desc').value = c?.description || '';
    Admin.openModal('category-modal');
  },

  _saveCat() {
    const id = document.getElementById('cat-modal-id').value;
    const data = {
      name: document.getElementById('cm-name').value,
      slug: document.getElementById('cm-slug').value || document.getElementById('cm-name').value.toLowerCase().replace(/\s+/g,'-'),
      icon: document.getElementById('cm-icon').value || '📦',
      description: document.getElementById('cm-desc').value,
    };
    if (!data.name) { Admin.toast('Category name is required', 'error'); return; }
    if (id) { DB.Categories.update(id, data); Admin.toast('Category updated!', 'success'); }
    else { DB.Categories.create(data); Admin.toast('Category created!', 'success'); }
    Admin.closeModal('category-modal');
    Sections._renderCategories();
  },

  _deleteCat(id) {
    Admin.confirm('Delete this category?', () => {
      DB.Categories.delete(id);
      Admin.toast('Category deleted', 'warning');
      Sections._renderCategories();
    });
  },

  // ---- ORDERS ----
  orders() {
    this._renderOrders(DB.Orders.all());
    const searchEl = document.getElementById('orders-search');
    if (searchEl) searchEl.oninput = () => {
      const q = searchEl.value.toLowerCase();
      const filtered = DB.Orders.all().filter(o => o.user_name.toLowerCase().includes(q) || String(o.id).includes(q));
      Sections._renderOrders(filtered);
    };
    const statusSel = document.getElementById('orders-status-filter');
    if (statusSel) statusSel.onchange = () => {
      const val = statusSel.value;
      const filtered = val ? DB.Orders.all().filter(o => o.status === val) : DB.Orders.all();
      Sections._renderOrders(filtered);
    };
  },

  _renderOrders(orders) {
    const el = document.getElementById('orders-table-body');
    if (!el) return;
    const sorted = [...orders].sort((a,b) => new Date(b.created_at) - new Date(a.created_at));
    el.innerHTML = sorted.length ? sorted.map(o => `
      <tr>
        <td><strong>#${o.id}</strong></td>
        <td>
          <div style="font-weight:600">${o.user_name}</div>
          <div style="font-size:0.75rem;color:var(--text-3)">${o.user_email}</div>
        </td>
        <td>${o.items.length} item${o.items.length !== 1 ? 's' : ''}</td>
        <td><strong>${Admin.formatCurrency(o.total)}</strong></td>
        <td>
          <select class="btn btn-ghost btn-sm" onchange="Sections._updateOrderStatus(${o.id}, this.value)" style="cursor:pointer">
            ${['pending','processing','shipped','delivered','cancelled'].map(s =>
              `<option value="${s}" ${o.status===s?'selected':''}>${s.charAt(0).toUpperCase()+s.slice(1)}</option>`
            ).join('')}
          </select>
        </td>
        <td>${Admin.formatDate(o.created_at)}</td>
        <td>
          <div class="actions">
            <button class="btn btn-ghost btn-sm btn-icon" onclick="Sections._viewOrder(${o.id})" title="View">👁️</button>
            <button class="btn btn-danger btn-sm btn-icon" onclick="Sections._deleteOrder(${o.id})" title="Delete">🗑️</button>
          </div>
        </td>
      </tr>`).join('') : `<tr><td colspan="7"><div class="empty-state"><div class="empty-icon">📦</div><h4>No orders found</h4></div></td></tr>`;
  },

  _updateOrderStatus(id, status) {
    DB.Orders.update(id, { status });
    Admin.toast(`Order #${id} updated to "${status}"`, 'success');
  },

  _viewOrder(id) {
    const o = DB.Orders.find(id);
    if (!o) return;
    const el = document.getElementById('order-detail-content');
    if (el) el.innerHTML = `
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:24px">
        <div>
          <div style="font-size:0.75rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-3);margin-bottom:6px">Customer</div>
          <div style="font-weight:600">${o.user_name}</div>
          <div style="font-size:0.875rem;color:var(--text-2)">${o.user_email}</div>
        </div>
        <div>
          <div style="font-size:0.75rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-3);margin-bottom:6px">Shipping Address</div>
          <div style="font-size:0.875rem">${o.address?.street}, ${o.address?.city}, ${o.address?.zip}</div>
        </div>
        <div>
          <div style="font-size:0.75rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-3);margin-bottom:6px">Payment</div>
          <div style="font-size:0.875rem;font-weight:600">${o.payment?.toUpperCase()}</div>
        </div>
        <div>
          <div style="font-size:0.75rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--text-3);margin-bottom:6px">Date</div>
          <div style="font-size:0.875rem">${Admin.formatDate(o.created_at)}</div>
        </div>
      </div>
      <div style="border-top:1px solid var(--border);padding-top:20px">
        <div style="font-weight:700;margin-bottom:12px">Order Items</div>
        ${o.items.map(i => `
          <div style="display:flex;gap:12px;align-items:center;padding:10px 0;border-bottom:1px solid var(--border)">
            <img src="${i.image}" style="width:48px;height:48px;object-fit:cover;border-radius:var(--radius-sm);border:1px solid var(--border)" onerror="this.src='https://via.placeholder.com/48'">
            <div style="flex:1">
              <div style="font-weight:600;font-size:0.875rem">${i.name}</div>
              <div style="font-size:0.75rem;color:var(--text-3)">Qty: ${i.qty} × ${Admin.formatCurrency(i.price)}</div>
            </div>
            <div style="font-weight:700">${Admin.formatCurrency(i.price * i.qty)}</div>
          </div>`).join('')}
        <div style="display:flex;justify-content:space-between;padding-top:16px;font-size:1.1rem;font-weight:800">
          <span>Total</span><span>${Admin.formatCurrency(o.total)}</span>
        </div>
      </div>`;
    Admin.openModal('order-detail-modal');
  },

  _deleteOrder(id) {
    Admin.confirm('Delete this order?', () => {
      DB.Orders.delete(id);
      Admin.toast('Order deleted', 'warning');
      Sections._renderOrders(DB.Orders.all());
    });
  },

  // ---- USERS ----
  users() {
    this._renderUsers(DB.Users.all());
    const searchEl = document.getElementById('users-search');
    if (searchEl) searchEl.oninput = () => {
      const q = searchEl.value.toLowerCase();
      const filtered = DB.Users.all().filter(u => u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q));
      Sections._renderUsers(filtered);
    };
    document.getElementById('add-user-btn') && (document.getElementById('add-user-btn').onclick = () => Sections._openUserModal(null));
  },

  _renderUsers(users) {
    const el = document.getElementById('users-table-body');
    if (!el) return;
    el.innerHTML = users.length ? users.map(u => {
      const orders = DB.Orders.forUser(u.id);
      const initials = u.name.split(' ').map(n => n[0]).join('').toUpperCase();
      return `<tr>
        <td>
          <div style="display:flex;align-items:center;gap:10px">
            <div class="avatar">${initials}</div>
            <div>
              <div style="font-weight:600">${u.name}</div>
              <div style="font-size:0.75rem;color:var(--text-3)">${u.email}</div>
            </div>
          </div>
        </td>
        <td><span class="badge ${u.role === 'admin' ? 'badge-purple' : 'badge-gray'}">${u.role}</span></td>
        <td>${orders.length} orders</td>
        <td>${Admin.formatCurrency(orders.reduce((s,o) => s+o.total, 0))}</td>
        <td>${Admin.formatDate(u.created_at)}</td>
        <td>
          <div class="actions">
            <button class="btn btn-ghost btn-sm btn-icon" onclick="Sections._openUserModal(${u.id})">✏️</button>
            ${u.role !== 'admin' ? `<button class="btn btn-danger btn-sm btn-icon" onclick="Sections._deleteUser(${u.id})">🗑️</button>` : ''}
          </div>
        </td>
      </tr>`;
    }).join('') : `<tr><td colspan="6"><div class="empty-state"><div class="empty-icon">👥</div><h4>No users found</h4></div></td></tr>`;
  },

  _openUserModal(id) {
    const u = id ? DB.Users.find(id) : null;
    document.getElementById('user-modal-title').textContent = id ? 'Edit User' : 'Add User';
    document.getElementById('user-modal-id').value = id || '';
    document.getElementById('um-name').value = u?.name || '';
    document.getElementById('um-email').value = u?.email || '';
    document.getElementById('um-password').value = '';
    document.getElementById('um-role').value = u?.role || 'customer';
    Admin.openModal('user-modal');
  },

  _saveUser() {
    const id = document.getElementById('user-modal-id').value;
    const data = {
      name: document.getElementById('um-name').value,
      email: document.getElementById('um-email').value,
      role: document.getElementById('um-role').value,
    };
    const pwd = document.getElementById('um-password').value;
    if (pwd) data.password = pwd;
    if (!data.name || !data.email) { Admin.toast('Name and email are required', 'error'); return; }

    if (id) { DB.Users.update(id, data); Admin.toast('User updated!', 'success'); }
    else {
      if (!pwd) { Admin.toast('Password is required for new users', 'error'); return; }
      DB.Users.create({ ...data, password: pwd });
      Admin.toast('User created!', 'success');
    }
    Admin.closeModal('user-modal');
    Sections._renderUsers(DB.Users.all());
  },

  _deleteUser(id) {
    Admin.confirm('Delete this user?', () => {
      DB.Users.delete(id);
      Admin.toast('User deleted', 'warning');
      Sections._renderUsers(DB.Users.all());
    });
  },

  settings() {
    // Settings section — simple static
  }
};

// Close modal on overlay click
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
  }
});

// Image preview update on input
document.addEventListener('input', e => {
  if (e.target.id === 'pm-images') Sections._updateImgPreviews();
  if (e.target.id === 'cm-name') {
    const slug = e.target.value.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    document.getElementById('cm-slug') && (document.getElementById('cm-slug').value = slug);
  }
});

Admin.init();
