// ============================================================
// SHOPEX — App Controller
// ============================================================

const App = {
  currentPage: null,

  init() {
    this.router();
    this.initCart();
    this.initHeader();
    this.updateCartBadge();
    this.initBackToTop();
  },

  router() {
    const hash = location.hash || '#home';
    this.navigate(hash);
    window.addEventListener('hashchange', () => this.navigate(location.hash));
  },

  navigate(hash) {
    const [page, param] = hash.replace('#','').split('/');
    document.querySelectorAll('.page').forEach(p => p.style.display = 'none');
    const target = document.getElementById('page-' + page);
    if (target) {
      target.style.display = 'block';
      this.currentPage = page;
      Pages[page] && Pages[page](param);
    } else {
      Pages.home && Pages.home();
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  },

  initHeader() {
    this.updateUserMenu();
  },

  updateUserMenu() {
    const user = DB.Session.get();
    const loginBtn = document.getElementById('header-login-btn');
    const userMenuEl = document.getElementById('header-user-menu');
    const userNameEl = document.getElementById('header-user-name');

    if (user) {
      loginBtn && (loginBtn.style.display = 'none');
      userMenuEl && (userMenuEl.style.display = 'flex');
      userNameEl && (userNameEl.textContent = user.name.split(' ')[0]);
    } else {
      loginBtn && (loginBtn.style.display = 'flex');
      userMenuEl && (userMenuEl.style.display = 'none');
    }
  },

  initCart() {
    const overlay = document.getElementById('cart-overlay');
    const sidebar = document.getElementById('cart-sidebar');
    overlay && overlay.addEventListener('click', () => App.closeCart());
    document.getElementById('close-cart') && document.getElementById('close-cart').addEventListener('click', () => App.closeCart());
    document.getElementById('cart-btn') && document.getElementById('cart-btn').addEventListener('click', () => App.openCart());
  },

  openCart() {
    document.getElementById('cart-overlay').classList.add('open');
    document.getElementById('cart-sidebar').classList.add('open');
    this.renderCart();
  },

  closeCart() {
    document.getElementById('cart-overlay').classList.remove('open');
    document.getElementById('cart-sidebar').classList.remove('open');
  },

  renderCart() {
    const cart = DB.Cart.get();
    const el = document.getElementById('cart-items-list');
    const footer = document.getElementById('cart-footer');
    if (!el) return;

    if (cart.length === 0) {
      el.innerHTML = `
        <div class="cart-empty">
          <div class="empty-icon">🛍️</div>
          <h4>Your cart is empty</h4>
          <p>Add some beautiful products to get started</p>
          <a href="#shop" class="btn btn-dark btn-sm" onclick="App.closeCart()">Browse Shop</a>
        </div>`;
      footer && (footer.style.display = 'none');
    } else {
      el.innerHTML = cart.map(item => `
        <div class="cart-item">
          <img class="cart-item-img" src="${item.image}" alt="${item.name}" onerror="this.src='https://via.placeholder.com/80x80?text=Item'">
          <div class="cart-item-info">
            <div class="cart-item-name">${item.name}</div>
            <div class="cart-item-price">$${item.price.toFixed(2)}</div>
            <div class="cart-item-actions">
              <button class="cart-qty-btn" onclick="App.cartUpdateQty(${item.id}, ${item.qty - 1})">−</button>
              <span class="cart-qty">${item.qty}</span>
              <button class="cart-qty-btn" onclick="App.cartUpdateQty(${item.id}, ${item.qty + 1})">+</button>
              <button class="cart-item-remove" onclick="App.cartRemove(${item.id})">✕ Remove</button>
            </div>
          </div>
          <div style="font-weight:700;font-size:0.95rem;flex-shrink:0;">$${(item.price * item.qty).toFixed(2)}</div>
        </div>`).join('');

      const subtotal = DB.Cart.total();
      const shipping = subtotal > 100 ? 0 : 9.99;
      const total = subtotal + shipping;
      footer && (footer.style.display = 'block');
      document.getElementById('cart-subtotal-val') && (document.getElementById('cart-subtotal-val').textContent = '$' + subtotal.toFixed(2));
      document.getElementById('cart-shipping-val') && (document.getElementById('cart-shipping-val').textContent = shipping === 0 ? 'FREE' : '$' + shipping.toFixed(2));
      document.getElementById('cart-total-val') && (document.getElementById('cart-total-val').textContent = '$' + total.toFixed(2));
    }
  },

  cartAdd(productId, qty=1) {
    const product = DB.Products.find(productId);
    if (!product) return;
    DB.Cart.add(product, qty);
    this.updateCartBadge();
    this.toast(`"${product.name}" added to cart!`, 'success');
    this.openCart();
  },

  cartRemove(id) {
    DB.Cart.remove(id);
    this.updateCartBadge();
    this.renderCart();
  },

  cartUpdateQty(id, qty) {
    DB.Cart.updateQty(id, qty);
    this.updateCartBadge();
    this.renderCart();
  },

  updateCartBadge() {
    const count = DB.Cart.count();
    document.querySelectorAll('.cart-count').forEach(el => {
      el.textContent = count;
      el.style.display = count > 0 ? 'flex' : 'none';
    });
  },

  toast(msg, type='') {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const t = document.createElement('div');
    t.className = `toast ${type}`;
    t.innerHTML = `<span>${type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ'}</span> ${msg}`;
    container.appendChild(t);
    setTimeout(() => t.remove(), 3500);
  },

  initBackToTop() {
    const btn = document.getElementById('back-to-top');
    if (!btn) return;
    window.addEventListener('scroll', () => {
      btn.classList.toggle('visible', window.scrollY > 400);
    });
    btn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  },

  logout() {
    DB.Session.clear();
    this.updateUserMenu();
    location.hash = '#home';
    this.toast('Logged out successfully');
  },

  requireLogin(next) {
    if (!DB.Session.isLoggedIn()) {
      document.getElementById('login-redirect') && (document.getElementById('login-redirect').value = next);
      location.hash = '#login';
      return false;
    }
    return true;
  },

  renderStars(rating) {
    const full = Math.floor(rating);
    const half = rating % 1 >= 0.5;
    let stars = '';
    for (let i = 0; i < 5; i++) {
      if (i < full) stars += '<span class="star">★</span>';
      else if (i === full && half) stars += '<span class="star">½</span>';
      else stars += '<span class="star empty">☆</span>';
    }
    return `<div class="star-rating">${stars}</div>`;
  },

  formatDate(iso) {
    return new Date(iso).toLocaleDateString('en-US', { year:'numeric', month:'short', day:'numeric' });
  },

  getCategoryName(id) {
    const cat = DB.Categories.find(id);
    return cat ? cat.name : 'Unknown';
  },

  renderProductCard(p) {
    const cat = DB.Categories.find(p.category_id);
    const catName = cat ? cat.name : '';
    const discount = p.original_price ? Math.round((1 - p.price/p.original_price)*100) : 0;
    return `
      <div class="product-card" onclick="location.hash='#product/${p.id}'">
        <div class="product-img-wrap">
          <img src="${p.images[0]}" alt="${p.name}" loading="lazy" onerror="this.src='https://via.placeholder.com/400x300?text=Product'">
          ${p.badge ? `<div class="product-badge ${p.badge.toLowerCase() === 'sale' ? 'sale' : p.badge.toLowerCase() === 'new' ? 'new' : ''}">${p.badge}</div>` : ''}
          ${discount > 0 ? `<div class="product-badge sale" style="top:${p.badge?'42px':'12px'}">-${discount}%</div>` : ''}
          <div class="product-actions">
            <button class="action-btn" title="Quick view" onclick="event.stopPropagation();location.hash='#product/${p.id}'">👁</button>
            <button class="action-btn" title="Add to wishlist" onclick="event.stopPropagation();App.toast('Added to wishlist!','success')">♡</button>
          </div>
        </div>
        <div class="product-body">
          <div class="product-cat">${catName}</div>
          <div class="product-name">${p.name}</div>
          <div class="product-rating">
            <div class="stars">${'★'.repeat(Math.floor(p.rating))}${'☆'.repeat(5-Math.floor(p.rating))}</div>
            <span class="rating-count">(${p.reviews})</span>
          </div>
          <div class="product-footer">
            <div class="product-price">
              <span class="price-current">$${p.price.toFixed(2)}</span>
              ${p.original_price ? `<span class="price-original">$${p.original_price.toFixed(2)}</span>` : ''}
            </div>
            <button class="add-cart-btn" title="Add to cart" onclick="event.stopPropagation();App.cartAdd(${p.id})">+</button>
          </div>
        </div>
      </div>`;
  }
};

// ============================================================
// PAGE CONTROLLERS
// ============================================================
const Pages = {

  home() {
    // Featured products
    const featured = DB.Products.featured().slice(0, 8);
    const grid = document.getElementById('featured-products');
    if (grid) grid.innerHTML = featured.map(p => App.renderProductCard(p)).join('');

    // Categories
    const cats = DB.Categories.all();
    const catGrid = document.getElementById('home-categories');
    if (catGrid) catGrid.innerHTML = cats.map(c => {
      const count = DB.Products.byCategory(c.id).length;
      return `<div class="category-card" onclick="location.hash='#shop?cat=${c.id}'">
        <div class="cat-icon">${c.icon}</div>
        <div class="cat-name">${c.name}</div>
        <div class="cat-count">${count} items</div>
      </div>`;
    }).join('');
  },

  shop(param) {
    const urlParams = new URLSearchParams(location.hash.split('?')[1] || '');
    const catFilter = urlParams.get('cat') || '';
    const searchQ = urlParams.get('q') || '';

    // Render category filters
    const filterEl = document.getElementById('shop-cat-filters');
    if (filterEl) {
      const cats = DB.Categories.all();
      filterEl.innerHTML = `
        <div class="filter-option">
          <input type="checkbox" id="cat-all" value="" ${!catFilter ? 'checked' : ''} onchange="Pages.applyFilters()">
          <label for="cat-all">All Categories</label>
        </div>
        ${cats.map(c => `
          <div class="filter-option">
            <input type="checkbox" id="cat-${c.id}" value="${c.id}" ${catFilter == c.id ? 'checked' : ''} onchange="Pages.applyFilters()">
            <label for="cat-${c.id}">${c.icon} ${c.name}</label>
          </div>`).join('')}`;
    }

    this.applyFilters();

    // Search box
    const shopSearch = document.getElementById('shop-search-input');
    if (shopSearch) {
      shopSearch.value = searchQ;
      shopSearch.oninput = () => this.applyFilters();
    }
  },

  applyFilters() {
    const checkedCats = [...document.querySelectorAll('#shop-cat-filters input:checked')].map(i => i.value).filter(Boolean);
    const sortVal = document.getElementById('shop-sort')?.value || 'default';
    const searchVal = document.getElementById('shop-search-input')?.value.toLowerCase() || '';
    const maxPrice = parseInt(document.getElementById('price-range-input')?.value || 9999);

    let products = DB.Products.all();

    if (checkedCats.length) products = products.filter(p => checkedCats.includes(String(p.category_id)));
    if (searchVal) products = products.filter(p => p.name.toLowerCase().includes(searchVal) || p.description.toLowerCase().includes(searchVal));
    products = products.filter(p => p.price <= maxPrice);

    if (sortVal === 'price-asc') products.sort((a,b) => a.price - b.price);
    else if (sortVal === 'price-desc') products.sort((a,b) => b.price - a.price);
    else if (sortVal === 'rating') products.sort((a,b) => b.rating - a.rating);
    else if (sortVal === 'newest') products.sort((a,b) => new Date(b.created_at) - new Date(a.created_at));

    const grid = document.getElementById('shop-products-grid');
    if (grid) {
      if (products.length === 0) {
        grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1">
          <div class="empty-icon">🔍</div>
          <h3>No products found</h3>
          <p>Try adjusting your search or filters</p>
        </div>`;
      } else {
        grid.innerHTML = products.map(p => App.renderProductCard(p)).join('');
      }
    }

    const countEl = document.getElementById('products-count');
    if (countEl) countEl.textContent = `${products.length} products`;
  },

  product(id) {
    const p = DB.Products.find(id);
    if (!p) { location.hash = '#shop'; return; }
    const cat = DB.Categories.find(p.category_id);

    // Breadcrumb
    const bc = document.getElementById('product-breadcrumb');
    if (bc) bc.innerHTML = `
      <a href="#home">Home</a> <span>/</span>
      <a href="#shop">Shop</a> <span>/</span>
      <a href="#shop?cat=${p.category_id}">${cat?.name || ''}</a> <span>/</span>
      <span>${p.name}</span>`;

    // Gallery
    const mainImg = document.getElementById('product-main-img');
    if (mainImg) mainImg.src = p.images[0];
    const thumbs = document.getElementById('product-thumbs');
    if (thumbs) thumbs.innerHTML = p.images.map((img, i) => `
      <div class="gallery-thumb ${i===0?'active':''}" onclick="Pages.switchImg(this, '${img}')">
        <img src="${img}" alt="" onerror="this.src='https://via.placeholder.com/72x72'">
      </div>`).join('');

    // Info
    const discount = p.original_price ? Math.round((1 - p.price/p.original_price)*100) : 0;
    document.getElementById('product-cat-label') && (document.getElementById('product-cat-label').textContent = cat?.name || '');
    document.getElementById('product-detail-name') && (document.getElementById('product-detail-name').textContent = p.name);
    document.getElementById('product-price-current') && (document.getElementById('product-price-current').textContent = '$' + p.price.toFixed(2));
    document.getElementById('product-price-original') && (document.getElementById('product-price-original').textContent = p.original_price ? '$' + p.original_price.toFixed(2) : '');
    document.getElementById('product-price-original') && (document.getElementById('product-price-original').style.display = p.original_price ? '' : 'none');
    document.getElementById('product-detail-rating') && (document.getElementById('product-detail-rating').innerHTML = App.renderStars(p.rating));
    document.getElementById('product-detail-reviews') && (document.getElementById('product-detail-reviews').textContent = `${p.reviews} reviews`);
    document.getElementById('product-detail-desc') && (document.getElementById('product-detail-desc').textContent = p.description);
    document.getElementById('product-stock') && (document.getElementById('product-stock').textContent = p.stock > 0 ? `✓ In stock (${p.stock})` : '✕ Out of stock');
    document.getElementById('product-stock') && (document.getElementById('product-stock').style.color = p.stock > 0 ? 'var(--success)' : 'var(--danger)');

    // ATC
    const atcBtn = document.getElementById('product-add-cart');
    if (atcBtn) atcBtn.onclick = () => {
      const qty = parseInt(document.getElementById('product-qty')?.textContent || '1');
      App.cartAdd(p.id, qty);
    };

    // Qty
    window.qtyChange = (delta) => {
      const el = document.getElementById('product-qty');
      if (!el) return;
      let q = parseInt(el.textContent) + delta;
      if (q < 1) q = 1;
      if (q > p.stock) q = p.stock;
      el.textContent = q;
    };

    // Related
    const related = DB.Products.byCategory(p.category_id).filter(r => r.id != p.id).slice(0, 4);
    const relGrid = document.getElementById('related-products');
    if (relGrid) relGrid.innerHTML = related.map(r => App.renderProductCard(r)).join('');
  },

  switchImg(thumb, src) {
    document.getElementById('product-main-img').src = src;
    document.querySelectorAll('.gallery-thumb').forEach(t => t.classList.remove('active'));
    thumb.classList.add('active');
  },

  checkout() {
    if (!App.requireLogin('checkout')) return;
    const cart = DB.Cart.get();
    if (cart.length === 0) { location.hash = '#shop'; return; }

    // Summary
    const summaryEl = document.getElementById('checkout-summary-items');
    if (summaryEl) {
      summaryEl.innerHTML = cart.map(i => `
        <div class="summary-item">
          <img class="summary-item-img" src="${i.image}" alt="${i.name}" onerror="this.src='https://via.placeholder.com/52x52'">
          <div class="summary-item-details">
            <div class="summary-item-name">${i.name}</div>
            <div class="summary-item-qty">Qty: ${i.qty}</div>
          </div>
          <div class="summary-item-price">$${(i.price * i.qty).toFixed(2)}</div>
        </div>`).join('');
    }

    const subtotal = DB.Cart.total();
    const shipping = subtotal > 100 ? 0 : 9.99;
    const tax = subtotal * 0.08;
    const total = subtotal + shipping + tax;

    document.getElementById('co-subtotal') && (document.getElementById('co-subtotal').textContent = '$' + subtotal.toFixed(2));
    document.getElementById('co-shipping') && (document.getElementById('co-shipping').textContent = shipping === 0 ? 'FREE' : '$' + shipping.toFixed(2));
    document.getElementById('co-tax') && (document.getElementById('co-tax').textContent = '$' + tax.toFixed(2));
    document.getElementById('co-total') && (document.getElementById('co-total').textContent = '$' + total.toFixed(2));

    // Pre-fill user info
    const user = DB.Session.get();
    if (user) {
      document.getElementById('co-email') && (document.getElementById('co-email').value = user.email);
      const [first, ...rest] = user.name.split(' ');
      document.getElementById('co-fname') && (document.getElementById('co-fname').value = first || '');
      document.getElementById('co-lname') && (document.getElementById('co-lname').value = rest.join(' ') || '');
    }

    // Place order
    document.getElementById('place-order-btn') && (document.getElementById('place-order-btn').onclick = () => {
      Pages.placeOrder(subtotal + shipping + tax);
    });
  },

  placeOrder(total) {
    const user = DB.Session.get();
    const fname = document.getElementById('co-fname')?.value;
    const lname = document.getElementById('co-lname')?.value;
    const address = document.getElementById('co-address')?.value;
    const city = document.getElementById('co-city')?.value;
    const zip = document.getElementById('co-zip')?.value;

    if (!fname || !address || !city || !zip) {
      App.toast('Please fill in all required fields', 'error'); return;
    }

    const selectedPayment = document.querySelector('.payment-option.selected')?.dataset.method || 'card';
    const cart = DB.Cart.get();

    const order = DB.Orders.create({
      user_id: user.id, user_name: user.name, user_email: user.email,
      items: cart.map(i => ({ product_id: i.id, name: i.name, price: i.price, qty: i.qty, image: i.image })),
      total, status: 'pending', payment: selectedPayment,
      address: { street: address, city, zip, country: document.getElementById('co-country')?.value || 'US' }
    });

    DB.Cart.clear();
    App.updateCartBadge();
    location.hash = '#order-success/' + order.id;
  },

  'order-success'(orderId) {
    const el = document.getElementById('order-success-id');
    if (el) el.textContent = '#' + orderId;
  },

  login() {
    document.getElementById('login-form') && (document.getElementById('login-form').onsubmit = (e) => {
      e.preventDefault();
      const email = document.getElementById('login-email').value;
      const password = document.getElementById('login-password').value;
      const user = DB.Users.authenticate(email, password);
      if (user) {
        DB.Session.set(user);
        App.updateUserMenu();
        App.toast(`Welcome back, ${user.name.split(' ')[0]}!`, 'success');
        const redirect = document.getElementById('login-redirect')?.value;
        location.hash = redirect ? '#' + redirect : (user.role === 'admin' ? '#admin' : '#home');
      } else {
        App.toast('Invalid email or password', 'error');
      }
    });

    // Demo credentials
    window.fillDemo = (role) => {
      if (role === 'admin') {
        document.getElementById('login-email').value = 'admin@shopex.com';
        document.getElementById('login-password').value = 'admin123';
      } else {
        document.getElementById('login-email').value = 'jane@example.com';
        document.getElementById('login-password').value = 'jane123';
      }
    };
  },

  register() {
    document.getElementById('register-form') && (document.getElementById('register-form').onsubmit = (e) => {
      e.preventDefault();
      const name = document.getElementById('reg-name').value;
      const email = document.getElementById('reg-email').value;
      const password = document.getElementById('reg-password').value;
      if (DB.Users.findByEmail(email)) {
        App.toast('Email already registered', 'error'); return;
      }
      const user = DB.Users.create({ name, email, password });
      DB.Session.set(user);
      App.updateUserMenu();
      App.toast('Account created! Welcome aboard!', 'success');
      location.hash = '#home';
    });
  },

  search() {
    const q = new URLSearchParams(location.hash.split('?')[1] || '').get('q') || '';
    const results = DB.Products.search(q);
    const el = document.getElementById('search-results-grid');
    const qEl = document.getElementById('search-query-display');
    const countEl = document.getElementById('search-count');
    if (qEl) qEl.textContent = `"${q}"`;
    if (countEl) countEl.textContent = results.length + ' results';
    if (el) el.innerHTML = results.length ? results.map(p => App.renderProductCard(p)).join('') :
      `<div class="empty-state" style="grid-column:1/-1">
        <div class="empty-icon">🔍</div>
        <h3>No results for "${q}"</h3>
        <p>Try different keywords or browse our categories</p>
        <a href="#shop" class="btn btn-dark btn-sm">Browse All</a>
      </div>`;
  },

  account() {
    if (!App.requireLogin('account')) return;
    const user = DB.Session.get();
    document.getElementById('account-name') && (document.getElementById('account-name').textContent = user.name);
    document.getElementById('account-email') && (document.getElementById('account-email').textContent = user.email);

    const orders = DB.Orders.forUser(user.id);
    const ordersEl = document.getElementById('my-orders-list');
    if (ordersEl) {
      ordersEl.innerHTML = orders.length ? orders.map(o => `
        <div style="border:1px solid var(--border);border-radius:var(--radius);padding:20px;margin-bottom:16px;">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
            <div>
              <strong>Order #${o.id}</strong>
              <span style="margin-left:12px;color:var(--ink-3);font-size:0.85rem;">${App.formatDate(o.created_at)}</span>
            </div>
            <span class="status-badge status-${o.status}">${o.status}</span>
          </div>
          <div style="font-size:0.875rem;color:var(--ink-2);">
            ${o.items.map(i => i.name + ' ×' + i.qty).join(', ')}
          </div>
          <div style="margin-top:12px;font-weight:700;">Total: $${o.total.toFixed(2)}</div>
        </div>`).join('') :
        `<div class="empty-state"><div class="empty-icon">📦</div><h3>No orders yet</h3><a href="#shop" class="btn btn-dark btn-sm">Start Shopping</a></div>`;
    }
  }
};

// Search form submit
document.getElementById('search-form-main') && document.getElementById('search-form-main').addEventListener('submit', (e) => {
  e.preventDefault();
  const q = document.getElementById('search-input-main').value.trim();
  if (q) location.hash = '#search?q=' + encodeURIComponent(q);
});

// Payment option select
document.addEventListener('click', (e) => {
  const opt = e.target.closest('.payment-option');
  if (opt) {
    document.querySelectorAll('.payment-option').forEach(o => o.classList.remove('selected'));
    opt.classList.add('selected');
  }
});

// Init
App.init();
