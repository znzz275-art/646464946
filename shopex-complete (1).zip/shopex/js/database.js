// ============================================================
// SHOPEX DATABASE LAYER — localStorage-based persistent store
// ============================================================

const DB = {
  _init() {
    if (!localStorage.getItem('db_initialized')) {
      this._seed();
      localStorage.setItem('db_initialized', '1');
    }
  },

  _seed() {
    const categories = [
      { id: 1, name: 'Electronics', slug: 'electronics', icon: '⚡', description: 'Latest gadgets and tech', color: '#6366f1' },
      { id: 2, name: 'Clothing',    slug: 'clothing',    icon: '👗', description: 'Fashion & apparel',      color: '#ec4899' },
      { id: 3, name: 'Home & Living', slug: 'home',      icon: '🏠', description: 'For your home',          color: '#f59e0b' },
      { id: 4, name: 'Sports',      slug: 'sports',      icon: '🏃', description: 'Sports & outdoors',      color: '#10b981' },
      { id: 5, name: 'Books',       slug: 'books',       icon: '📚', description: 'Books & media',          color: '#8b5cf6' },
      { id: 6, name: 'Beauty',      slug: 'beauty',      icon: '✨', description: 'Beauty & wellness',      color: '#f43f5e' },
    ];

    const products = [
      { id:1, name:'Pro Wireless Headphones', category_id:1, price:299.99, original_price:399.99, stock:45, rating:4.8, reviews:234, description:'Premium noise-cancelling wireless headphones with 30-hour battery life. Experience studio-quality sound with adaptive ANC, spatial audio, and multipoint connection. The ultra-soft memory foam ear cushions ensure comfort even during long sessions.', images:['https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&q=80','https://images.unsplash.com/photo-1484704849700-f032a568e944?w=600&q=80'], featured:true, badge:'Best Seller', created_at: new Date().toISOString() },
      { id:2, name:'4K Ultra Smart Watch', category_id:1, price:449.00, original_price:599.00, stock:28, rating:4.9, reviews:187, description:'Next-generation smartwatch with AMOLED display, health monitoring suite including ECG, SpO2, blood glucose estimation, and 7-day battery. Water resistant to 100m. Supports over 100 workout modes.', images:['https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&q=80','https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=600&q=80'], featured:true, badge:'New', created_at: new Date().toISOString() },
      { id:3, name:'Minimalist Leather Jacket', category_id:2, price:189.00, original_price:250.00, stock:15, rating:4.7, reviews:89, description:'Hand-crafted genuine leather jacket with a slim contemporary cut. Features a full satin lining, two inner pockets, and antique brass hardware. Available in Midnight Black and Cognac Brown.', images:['https://images.unsplash.com/photo-1551028719-00167b16eac5?w=600&q=80','https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=600&q=80'], featured:true, badge:'Sale', created_at: new Date().toISOString() },
      { id:4, name:'Ergonomic Office Chair', category_id:3, price:549.00, original_price:699.00, stock:12, rating:4.6, reviews:312, description:'Fully adjustable ergonomic chair with lumbar support system, 4D armrests, synchronized tilt mechanism, and breathable mesh back. Supports up to 300 lbs. BIFMA certified. 5-year warranty included.', images:['https://images.unsplash.com/photo-1592078615290-033ee584e267?w=600&q=80','https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=600&q=80'], featured:true, badge:'Popular', created_at: new Date().toISOString() },
      { id:5, name:'Trail Running Shoes', category_id:4, price:139.99, original_price:170.00, stock:67, rating:4.5, reviews:445, description:'Lightweight trail running shoes with Vibram® outsole, Gore-Tex waterproof membrane, and responsive foam midsole. Rock plate protection, toe cap reinforcement, and 360° reflectivity for night runs.', images:['https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&q=80','https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=600&q=80'], featured:false, badge:'', created_at: new Date().toISOString() },
      { id:6, name:'Design Thinking Masterclass', category_id:5, price:49.99, original_price:79.99, stock:999, rating:4.9, reviews:1203, description:'The definitive guide to design thinking, UX research, and product strategy. 600 pages of frameworks, case studies, and practical exercises used at top tech companies worldwide. Includes digital worksheets.', images:['https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=600&q=80','https://images.unsplash.com/photo-1512820790803-83ca734da794?w=600&q=80'], featured:false, badge:'', created_at: new Date().toISOString() },
      { id:7, name:'Luxury Skincare Set', category_id:6, price:215.00, original_price:280.00, stock:33, rating:4.8, reviews:567, description:'A complete 6-piece skincare ritual featuring vitamin C serum, hyaluronic acid moisturiser, retinol night cream, SPF 50 sunscreen, rose water toner, and exfoliating face mask. Dermatologist tested, cruelty-free, and vegan.', images:['https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=600&q=80','https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=600&q=80'], featured:true, badge:'Trending', created_at: new Date().toISOString() },
      { id:8, name:'Mechanical Keyboard Pro', category_id:1, price:179.99, original_price:220.00, stock:54, rating:4.7, reviews:298, description:'Full-size mechanical keyboard with Cherry MX switches, per-key RGB backlighting, aluminium top plate, and USB-C detachable cable. N-key rollover, programmable macros, and Windows/Mac compatibility.', images:['https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=600&q=80','https://images.unsplash.com/photo-1618384887929-16ec33fab9ef?w=600&q=80'], featured:false, badge:'', created_at: new Date().toISOString() },
      { id:9, name:'Yoga & Meditation Set', category_id:4, price:89.99, original_price:120.00, stock:88, rating:4.6, reviews:234, description:'Complete yoga starter kit including 6mm non-slip mat, two foam blocks, a cotton strap, microfibre mat towel, and carry bag. Eco-friendly TPE material, free from harmful chemicals. Perfect for beginners and seasoned practitioners.', images:['https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=600&q=80','https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=600&q=80'], featured:false, badge:'', created_at: new Date().toISOString() },
      { id:10, name:'Ceramic Pour-Over Coffee Set', category_id:3, price:75.00, original_price:95.00, stock:41, rating:4.8, reviews:189, description:'Hand-thrown ceramic pour-over dripper with matching server, two cups, and gooseneck kettle. Slow extraction brewing reveals complex flavour notes. Each piece is unique with natural glaze variations. Dishwasher safe.', images:['https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=600&q=80','https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=600&q=80'], featured:false, badge:'', created_at: new Date().toISOString() },
      { id:11, name:'Merino Wool Sweater', category_id:2, price:125.00, original_price:160.00, stock:29, rating:4.7, reviews:156, description:'Ultra-fine 18.5-micron merino wool sweater, naturally temperature-regulating, moisture-wicking, and odour-resistant. Relaxed fit, ribbed cuffs and hem. Machine washable on gentle cycle. Sustainably sourced from New Zealand.', images:['https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=600&q=80','https://images.unsplash.com/photo-1516762689617-e1cffcef479d?w=600&q=80'], featured:false, badge:'', created_at: new Date().toISOString() },
      { id:12, name:'Wireless Gaming Mouse', category_id:1, price:119.99, original_price:149.99, stock:73, rating:4.9, reviews:892, description:'Ultra-lightweight 58g gaming mouse with HERO 25K optical sensor, up to 25,600 DPI, 70-hour battery with power play charging, LIGHTSYNC RGB, 6 programmable buttons, and zero-compromise performance.', images:['https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=600&q=80','https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?w=600&q=80'], featured:false, badge:'', created_at: new Date().toISOString() },
    ];

    const users = [
      { id:1, name:'Admin User', email:'admin@shopex.com', password:'admin123', role:'admin', avatar:'', created_at: new Date().toISOString(), orders:0 },
      { id:2, name:'Jane Cooper', email:'jane@example.com', password:'jane123', role:'customer', avatar:'', created_at: new Date().toISOString(), orders:3 },
      { id:3, name:'Alex Morgan', email:'alex@example.com', password:'alex123', role:'customer', avatar:'', created_at: new Date().toISOString(), orders:1 },
    ];

    const orders = [
      { id:1, user_id:2, user_name:'Jane Cooper', user_email:'jane@example.com', items:[{product_id:1,name:'Pro Wireless Headphones',price:299.99,qty:1,image:'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=200&q=80'},{product_id:3,name:'Minimalist Leather Jacket',price:189.00,qty:1,image:'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=200&q=80'}], total:488.99, status:'delivered', payment:'card', address:{street:'123 Main St',city:'New York',zip:'10001',country:'US'}, created_at:'2025-01-15T10:30:00Z' },
      { id:2, user_id:3, user_name:'Alex Morgan', user_email:'alex@example.com', items:[{product_id:2,name:'4K Ultra Smart Watch',price:449.00,qty:1,image:'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200&q=80'}], total:449.00, status:'processing', payment:'paypal', address:{street:'456 Oak Ave',city:'Los Angeles',zip:'90001',country:'US'}, created_at:'2025-01-18T14:20:00Z' },
      { id:3, user_id:2, user_name:'Jane Cooper', user_email:'jane@example.com', items:[{product_id:7,name:'Luxury Skincare Set',price:215.00,qty:2,image:'https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=200&q=80'}], total:430.00, status:'shipped', payment:'card', address:{street:'123 Main St',city:'New York',zip:'10001',country:'US'}, created_at:'2025-01-20T09:15:00Z' },
      { id:4, user_id:2, user_name:'Jane Cooper', user_email:'jane@example.com', items:[{product_id:4,name:'Ergonomic Office Chair',price:549.00,qty:1,image:'https://images.unsplash.com/photo-1592078615290-033ee584e267?w=200&q=80'}], total:549.00, status:'pending', payment:'card', address:{street:'123 Main St',city:'New York',zip:'10001',country:'US'}, created_at:'2025-01-22T16:45:00Z' },
    ];

    localStorage.setItem('db_categories', JSON.stringify(categories));
    localStorage.setItem('db_products', JSON.stringify(products));
    localStorage.setItem('db_users', JSON.stringify(users));
    localStorage.setItem('db_orders', JSON.stringify(orders));
    localStorage.setItem('db_nextId', JSON.stringify({ product: 13, user: 4, order: 5, category: 7 }));
  },

  _nextId(table) {
    const ids = JSON.parse(localStorage.getItem('db_nextId') || '{}');
    const id = ids[table] || 1;
    ids[table] = id + 1;
    localStorage.setItem('db_nextId', JSON.stringify(ids));
    return id;
  },

  // ---- PRODUCTS ----
  Products: {
    all() { return JSON.parse(localStorage.getItem('db_products') || '[]'); },
    find(id) { return this.all().find(p => p.id == id) || null; },
    where(fn) { return this.all().filter(fn); },
    featured() { return this.all().filter(p => p.featured); },
    byCategory(cat_id) { return this.all().filter(p => p.category_id == cat_id); },
    search(q) {
      q = q.toLowerCase();
      return this.all().filter(p => p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q));
    },
    create(data) {
      const all = this.all();
      const item = { ...data, id: DB._nextId('product'), created_at: new Date().toISOString() };
      all.push(item);
      localStorage.setItem('db_products', JSON.stringify(all));
      return item;
    },
    update(id, data) {
      const all = this.all();
      const idx = all.findIndex(p => p.id == id);
      if (idx === -1) return null;
      all[idx] = { ...all[idx], ...data };
      localStorage.setItem('db_products', JSON.stringify(all));
      return all[idx];
    },
    delete(id) {
      const all = this.all().filter(p => p.id != id);
      localStorage.setItem('db_products', JSON.stringify(all));
      return true;
    },
  },

  // ---- CATEGORIES ----
  Categories: {
    all() { return JSON.parse(localStorage.getItem('db_categories') || '[]'); },
    find(id) { return this.all().find(c => c.id == id) || null; },
    create(data) {
      const all = this.all();
      const item = { ...data, id: DB._nextId('category') };
      all.push(item);
      localStorage.setItem('db_categories', JSON.stringify(all));
      return item;
    },
    update(id, data) {
      const all = this.all();
      const idx = all.findIndex(c => c.id == id);
      if (idx === -1) return null;
      all[idx] = { ...all[idx], ...data };
      localStorage.setItem('db_categories', JSON.stringify(all));
      return all[idx];
    },
    delete(id) {
      const all = this.all().filter(c => c.id != id);
      localStorage.setItem('db_categories', JSON.stringify(all));
      return true;
    },
  },

  // ---- USERS ----
  Users: {
    all() { return JSON.parse(localStorage.getItem('db_users') || '[]'); },
    find(id) { return this.all().find(u => u.id == id) || null; },
    findByEmail(email) { return this.all().find(u => u.email === email) || null; },
    authenticate(email, password) {
      const u = this.findByEmail(email);
      if (!u) return null;
      return u.password === password ? u : null;
    },
    create(data) {
      const all = this.all();
      const item = { ...data, id: DB._nextId('user'), role:'customer', created_at: new Date().toISOString(), orders:0 };
      all.push(item);
      localStorage.setItem('db_users', JSON.stringify(all));
      return item;
    },
    update(id, data) {
      const all = this.all();
      const idx = all.findIndex(u => u.id == id);
      if (idx === -1) return null;
      all[idx] = { ...all[idx], ...data };
      localStorage.setItem('db_users', JSON.stringify(all));
      return all[idx];
    },
    delete(id) {
      const all = this.all().filter(u => u.id != id);
      localStorage.setItem('db_users', JSON.stringify(all));
      return true;
    },
  },

  // ---- ORDERS ----
  Orders: {
    all() { return JSON.parse(localStorage.getItem('db_orders') || '[]'); },
    find(id) { return this.all().find(o => o.id == id) || null; },
    forUser(uid) { return this.all().filter(o => o.user_id == uid); },
    create(data) {
      const all = this.all();
      const item = { ...data, id: DB._nextId('order'), created_at: new Date().toISOString() };
      all.push(item);
      localStorage.setItem('db_orders', JSON.stringify(all));
      return item;
    },
    update(id, data) {
      const all = this.all();
      const idx = all.findIndex(o => o.id == id);
      if (idx === -1) return null;
      all[idx] = { ...all[idx], ...data };
      localStorage.setItem('db_orders', JSON.stringify(all));
      return all[idx];
    },
    delete(id) {
      const all = this.all().filter(o => o.id != id);
      localStorage.setItem('db_orders', JSON.stringify(all));
      return true;
    },
    stats() {
      const orders = this.all();
      const total = orders.reduce((s, o) => s + o.total, 0);
      const byStatus = {};
      orders.forEach(o => { byStatus[o.status] = (byStatus[o.status] || 0) + 1; });
      // monthly sales last 6 months
      const monthly = {};
      const now = new Date();
      for (let i = 5; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const key = d.toLocaleString('default', { month: 'short' });
        monthly[key] = 0;
      }
      orders.forEach(o => {
        const d = new Date(o.created_at);
        const key = d.toLocaleString('default', { month: 'short' });
        if (monthly[key] !== undefined) monthly[key] += o.total;
      });
      return { total, count: orders.length, byStatus, monthly };
    }
  },

  // ---- SESSION ----
  Session: {
    get() { return JSON.parse(sessionStorage.getItem('current_user') || 'null'); },
    set(user) { sessionStorage.setItem('current_user', JSON.stringify(user)); },
    clear() { sessionStorage.removeItem('current_user'); },
    isAdmin() { const u = this.get(); return u && u.role === 'admin'; },
    isLoggedIn() { return !!this.get(); },
  },

  // ---- CART ----
  Cart: {
    get() { return JSON.parse(localStorage.getItem('cart') || '[]'); },
    save(cart) { localStorage.setItem('cart', JSON.stringify(cart)); },
    add(product, qty=1) {
      const cart = this.get();
      const idx = cart.findIndex(i => i.id === product.id);
      if (idx > -1) cart[idx].qty += qty;
      else cart.push({ id: product.id, name: product.name, price: product.price, image: product.images[0], qty });
      this.save(cart);
      return cart;
    },
    remove(id) {
      const cart = this.get().filter(i => i.id !== id);
      this.save(cart);
      return cart;
    },
    updateQty(id, qty) {
      const cart = this.get();
      const idx = cart.findIndex(i => i.id === id);
      if (idx > -1) {
        if (qty <= 0) return this.remove(id);
        cart[idx].qty = qty;
      }
      this.save(cart);
      return cart;
    },
    clear() { this.save([]); },
    total() { return this.get().reduce((s, i) => s + i.price * i.qty, 0); },
    count() { return this.get().reduce((s, i) => s + i.qty, 0); },
  }
};

// Auto-init
DB._init();
