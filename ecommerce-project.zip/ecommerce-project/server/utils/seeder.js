const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config();

const User = require('../models/User');
const Product = require('../models/Product');
const Order = require('../models/Order');

const users = [
  { name: 'Admin User', email: 'admin@shoplux.com', password: 'admin123', role: 'admin' },
  { name: 'Jane Smith', email: 'jane@example.com', password: 'password123', role: 'user' },
  { name: 'John Doe', email: 'john@example.com', password: 'password123', role: 'user' },
];

const products = [
  {
    name: 'Premium Wireless Headphones',
    description: 'Experience unparalleled sound quality with these premium wireless headphones. Featuring 40-hour battery life, active noise cancellation, and ultra-comfortable ear cushions for all-day listening.',
    price: 299.99, originalPrice: 399.99, category: 'Electronics',
    brand: 'SoundPro', stock: 50, featured: true, rating: 4.5, numReviews: 128,
    images: ['https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600'],
    tags: ['wireless', 'audio', 'headphones'],
  },
  {
    name: 'Minimalist Leather Watch',
    description: 'A timeless piece of craftsmanship. This minimalist watch features a genuine leather strap, sapphire crystal glass, and Swiss movement for unmatched precision.',
    price: 189.99, originalPrice: 250.00, category: 'Accessories',
    brand: 'ChronoLux', stock: 30, featured: true, rating: 4.8, numReviews: 89,
    images: ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600'],
    tags: ['watch', 'leather', 'minimalist'],
  },
  {
    name: 'Ultra-Slim Laptop Backpack',
    description: 'Designed for the modern professional. This 30L backpack features a padded laptop compartment, USB charging port, water-resistant exterior, and ergonomic straps.',
    price: 89.99, originalPrice: 120.00, category: 'Bags',
    brand: 'TravelTech', stock: 75, featured: true, rating: 4.6, numReviews: 203,
    images: ['https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600'],
    tags: ['backpack', 'travel', 'laptop'],
  },
  {
    name: 'Smart Fitness Tracker',
    description: 'Track your health goals with precision. Features heart rate monitoring, sleep tracking, GPS, 7-day battery life, and is swim-proof to 50 meters.',
    price: 149.99, originalPrice: 199.99, category: 'Electronics',
    brand: 'FitPulse', stock: 60, featured: true, rating: 4.3, numReviews: 312,
    images: ['https://images.unsplash.com/photo-1575311373937-040b8e1fd5b6?w=600'],
    tags: ['fitness', 'tracker', 'health'],
  },
  {
    name: 'Artisan Coffee Maker',
    description: 'Brew café-quality coffee at home. This pour-over system with built-in grinder extracts maximum flavor from your beans. Includes precision temperature control.',
    price: 124.99, originalPrice: 160.00, category: 'Kitchen',
    brand: 'BrewMaster', stock: 25, featured: false, rating: 4.7, numReviews: 156,
    images: ['https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=600'],
    tags: ['coffee', 'kitchen', 'brewing'],
  },
  {
    name: 'Merino Wool Sweater',
    description: 'Luxuriously soft and naturally temperature-regulating. This 100% merino wool sweater is perfect for any season — warm in winter, cool in summer.',
    price: 79.99, originalPrice: 110.00, category: 'Clothing',
    brand: 'WoolCraft', stock: 40, featured: false, rating: 4.5, numReviews: 94,
    images: ['https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=600'],
    tags: ['wool', 'sweater', 'fashion'],
  },
  {
    name: 'Portable Bluetooth Speaker',
    description: '360° immersive sound in a compact design. IPX7 waterproof, 24-hour battery, and connects up to 2 devices simultaneously. Perfect for outdoor adventures.',
    price: 59.99, originalPrice: 79.99, category: 'Electronics',
    brand: 'SoundPro', stock: 100, featured: false, rating: 4.4, numReviews: 445,
    images: ['https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=600'],
    tags: ['speaker', 'bluetooth', 'portable'],
  },
  {
    name: 'Yoga Mat Pro',
    description: 'Studio-quality grip meets sustainable materials. Extra-thick 6mm cushioning provides joint protection, while the natural rubber base prevents slipping.',
    price: 45.99, originalPrice: 60.00, category: 'Sports',
    brand: 'ZenFlex', stock: 80, featured: false, rating: 4.6, numReviews: 267,
    images: ['https://images.unsplash.com/photo-1601925228008-b9c4e1073b04?w=600'],
    tags: ['yoga', 'fitness', 'mat'],
  },
  {
    name: 'Ceramic Cookware Set',
    description: '10-piece non-stick ceramic cookware set. PFOA-free, dishwasher safe, and compatible with all stovetops including induction. Oven safe to 450°F.',
    price: 199.99, originalPrice: 280.00, category: 'Kitchen',
    brand: 'ChefElite', stock: 20, featured: false, rating: 4.8, numReviews: 138,
    images: ['https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600'],
    tags: ['cookware', 'kitchen', 'ceramic'],
  },
  {
    name: 'Running Shoes Elite',
    description: 'Engineered for speed and comfort. Carbon fiber plate, responsive foam cushioning, and breathable mesh upper. Designed for both track and road running.',
    price: 159.99, originalPrice: 210.00, category: 'Sports',
    brand: 'SwiftRun', stock: 45, featured: true, rating: 4.7, numReviews: 389,
    images: ['https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600'],
    tags: ['shoes', 'running', 'sports'],
  },
  {
    name: 'Mechanical Keyboard TKL',
    description: 'Precision typing with tactile satisfaction. Cherry MX switches, PBT double-shot keycaps, per-key RGB lighting, and USB-C connectivity. Built to last.',
    price: 129.99, originalPrice: 159.99, category: 'Electronics',
    brand: 'TypeMaster', stock: 35, featured: false, rating: 4.5, numReviews: 198,
    images: ['https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=600'],
    tags: ['keyboard', 'mechanical', 'gaming'],
  },
  {
    name: 'Scented Soy Candle Set',
    description: 'Hand-poured using 100% natural soy wax and premium fragrance oils. Set of 4 candles: Vanilla Bean, Cedar & Sandalwood, Fresh Linen, and Sea Breeze.',
    price: 34.99, originalPrice: 45.00, category: 'Home',
    brand: 'LuxeScents', stock: 90, featured: false, rating: 4.9, numReviews: 512,
    images: ['https://images.unsplash.com/photo-1602607144056-90c55f5e10a8?w=600'],
    tags: ['candles', 'home', 'decor'],
  },
];

const seedDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/ecommerce');
    console.log('Connected to MongoDB');

    await User.deleteMany();
    await Product.deleteMany();
    await Order.deleteMany();
    console.log('Cleared existing data');

    const createdUsers = await User.create(users);
    console.log(`✅ Created ${createdUsers.length} users`);

    const createdProducts = await Product.create(products);
    console.log(`✅ Created ${createdProducts.length} products`);

    // Create sample orders
    const sampleOrders = [
      {
        user: createdUsers[1]._id,
        orderItems: [{ product: createdProducts[0]._id, name: createdProducts[0].name, image: createdProducts[0].images[0], price: createdProducts[0].price, quantity: 1 }],
        shippingAddress: { fullName: 'Jane Smith', address: '123 Main St', city: 'New York', state: 'NY', zipCode: '10001', country: 'USA', phone: '555-0100' },
        paymentMethod: 'Credit Card',
        itemsPrice: 299.99, shippingPrice: 0, taxPrice: 30.00, totalPrice: 329.99,
        status: 'delivered', isPaid: true, paidAt: new Date(), isDelivered: true, deliveredAt: new Date(),
      },
      {
        user: createdUsers[2]._id,
        orderItems: [
          { product: createdProducts[1]._id, name: createdProducts[1].name, image: createdProducts[1].images[0], price: createdProducts[1].price, quantity: 1 },
          { product: createdProducts[3]._id, name: createdProducts[3].name, image: createdProducts[3].images[0], price: createdProducts[3].price, quantity: 2 },
        ],
        shippingAddress: { fullName: 'John Doe', address: '456 Oak Ave', city: 'Los Angeles', state: 'CA', zipCode: '90001', country: 'USA', phone: '555-0200' },
        paymentMethod: 'PayPal',
        itemsPrice: 489.97, shippingPrice: 9.99, taxPrice: 49.00, totalPrice: 548.96,
        status: 'processing', isPaid: true, paidAt: new Date(),
      },
    ];

    await Order.create(sampleOrders);
    console.log('✅ Created sample orders');
    console.log('\n🎉 Database seeded successfully!');
    console.log('Admin: admin@shoplux.com / admin123');
    process.exit(0);
  } catch (err) {
    console.error('❌ Seeding error:', err);
    process.exit(1);
  }
};

seedDB();
