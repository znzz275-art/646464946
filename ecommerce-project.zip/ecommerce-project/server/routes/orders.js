const express = require('express');
const router = express.Router();
const {
  createOrder, getMyOrders, getOrderById, updateOrderToPaid,
  getAllOrders, updateOrderStatus, getDashboardStats,
} = require('../controllers/orderController');
const { protect, admin } = require('../middleware/authMiddleware');

router.post('/', protect, createOrder);
router.get('/myorders', protect, getMyOrders);
router.get('/admin/stats', protect, admin, getDashboardStats);
router.get('/admin/all', protect, admin, getAllOrders);
router.get('/:id', protect, getOrderById);
router.put('/:id/pay', protect, updateOrderToPaid);
router.put('/:id/status', protect, admin, updateOrderStatus);

module.exports = router;
