import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Package, ChevronRight } from 'lucide-react';
import api from '../utils/api';
import { PageLoader } from '../components/common/Loader';

const statusColors = {
  pending: 'bg-yellow-100 text-yellow-700',
  processing: 'bg-blue-100 text-blue-700',
  shipped: 'bg-purple-100 text-purple-700',
  delivered: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
};

export default function OrdersPage() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/orders/myorders').then(r => setOrders(r.data)).finally(() => setLoading(false));
  }, []);

  if (loading) return <PageLoader />;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="font-display text-3xl font-bold text-gray-900 mb-8">My Orders</h1>
      {orders.length === 0 ? (
        <div className="text-center py-20">
          <Package className="w-16 h-16 text-gray-200 mx-auto mb-4" />
          <h3 className="font-semibold text-xl mb-2">No orders yet</h3>
          <Link to="/products" className="btn-primary inline-flex mt-4">Start Shopping</Link>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map(order => (
            <Link key={order._id} to={`/orders/${order._id}`} className="card p-5 flex items-center gap-4 hover:shadow-md transition-shadow group">
              <div className="flex -space-x-2">
                {order.orderItems.slice(0, 3).map((item, i) => (
                  <img key={i} src={item.image} alt={item.name} className="w-12 h-12 rounded-lg object-cover border-2 border-white" />
                ))}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-gray-900 text-sm truncate">{order.orderItems.map(i => i.name).join(', ')}</p>
                <p className="text-xs text-gray-500 mt-0.5">{new Date(order.createdAt).toLocaleDateString()} • {order.orderItems.length} item(s)</p>
              </div>
              <div className="text-right flex-shrink-0">
                <p className="font-bold text-gray-900">${order.totalPrice.toFixed(2)}</p>
                <span className={`badge text-xs mt-1 ${statusColors[order.status] || 'bg-gray-100 text-gray-600'}`}>{order.status}</span>
              </div>
              <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-orange-600" />
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
