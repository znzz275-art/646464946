import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Truck, Shield, RefreshCw, Headphones, Star } from 'lucide-react';
import api from '../utils/api';
import ProductCard from '../components/product/ProductCard';
import { ProductSkeleton } from '../components/common/Loader';

export default function HomePage() {
  const [featured, setFeatured] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [prodRes, catRes] = await Promise.all([
          api.get('/products?featured=true&limit=8'),
          api.get('/products/categories'),
        ]);
        setFeatured(prodRes.data.products);
        setCategories(catRes.data);
      } catch (err) { console.error(err); }
      finally { setLoading(false); }
    };
    load();
  }, []);

  const features = [
    { icon: Truck, title: 'Free Shipping', desc: 'On all orders over $50' },
    { icon: Shield, title: 'Secure Payment', desc: '100% secure transactions' },
    { icon: RefreshCw, title: 'Easy Returns', desc: '30-day return policy' },
    { icon: Headphones, title: '24/7 Support', desc: 'Always here to help' },
  ];

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white overflow-hidden relative">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-20 left-20 w-96 h-96 rounded-full bg-orange-500 blur-3xl" />
          <div className="absolute bottom-10 right-20 w-64 h-64 rounded-full bg-orange-400 blur-3xl" />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-20 lg:py-28 relative">
          <div className="max-w-2xl animate-slide-up">
            <span className="inline-block badge bg-orange-600/20 text-orange-400 border border-orange-500/30 mb-4 text-sm px-4 py-1.5">
              ✨ New arrivals every week
            </span>
            <h1 className="font-display text-5xl lg:text-6xl font-bold leading-tight mb-6">
              Discover Products<br />
              <span className="text-orange-500">Worth Owning</span>
            </h1>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Curated selection of premium products. From everyday essentials to special finds — quality you can feel.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/products" className="btn-primary text-base py-3.5 px-8 rounded-xl">
                Shop Now <ArrowRight className="w-5 h-5" />
              </Link>
              <Link to="/products?featured=true" className="border-2 border-white/30 hover:border-white text-white font-semibold px-8 py-3.5 rounded-xl transition-colors flex items-center gap-2">
                Featured Items
              </Link>
            </div>
            <div className="flex items-center gap-6 mt-10 pt-8 border-t border-white/10">
              {[['10K+', 'Happy Customers'], ['500+', 'Products'], ['4.9★', 'Average Rating']].map(([val, label]) => (
                <div key={label}>
                  <div className="font-bold text-2xl text-white">{val}</div>
                  <div className="text-gray-400 text-sm">{label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="flex items-center gap-3">
                <div className="w-10 h-10 bg-orange-100 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Icon className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900 text-sm">{title}</p>
                  <p className="text-gray-500 text-xs">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      {categories.length > 0 && (
        <section className="py-14 max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between mb-8">
            <h2 className="font-display text-3xl font-bold text-gray-900">Shop by Category</h2>
            <Link to="/products" className="text-orange-600 hover:text-orange-700 font-medium text-sm flex items-center gap-1">
              View all <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="flex flex-wrap gap-3">
            {categories.map(cat => (
              <Link key={cat} to={`/products?category=${encodeURIComponent(cat)}`}
                className="px-5 py-2.5 bg-white border border-gray-200 rounded-full text-sm font-medium hover:border-orange-600 hover:text-orange-600 hover:bg-orange-50 transition-all">
                {cat}
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Featured Products */}
      <section className="pb-16 max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="font-display text-3xl font-bold text-gray-900">Featured Products</h2>
            <p className="text-gray-500 mt-1">Handpicked favorites just for you</p>
          </div>
          <Link to="/products" className="hidden sm:flex items-center gap-1 text-orange-600 hover:text-orange-700 font-medium text-sm">
            View all <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {loading ? Array(8).fill(0).map((_, i) => <ProductSkeleton key={i} />) :
            featured.map(p => <ProductCard key={p._id} product={p} />)
          }
        </div>
        <div className="text-center mt-10">
          <Link to="/products" className="btn-secondary inline-flex">
            Browse All Products <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="bg-orange-600 py-16">
        <div className="max-w-3xl mx-auto px-4 text-center text-white">
          <h2 className="font-display text-4xl font-bold mb-4">Ready to Start Shopping?</h2>
          <p className="text-orange-100 text-lg mb-8">Join thousands of happy customers who trust ShopLux for their everyday needs.</p>
          <Link to="/register" className="bg-white text-orange-600 font-bold px-8 py-3.5 rounded-xl hover:bg-orange-50 transition-colors inline-flex items-center gap-2">
            Create Free Account <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
