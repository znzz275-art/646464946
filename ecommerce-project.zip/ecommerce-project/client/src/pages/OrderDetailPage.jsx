import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, MapPin, CreditCard } from 'lucide-react';
import api from '../utils/api';
import { PageLoader } from '../components/common/Loader';

const statusColors = {
  pending: 'bg-yellow-100 text-yellow-700',
  processing: 'bg-blue-100 text-blue-700',
  shipped: 'bg-purple-100 text-purple-700',
  delivered: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
};

export default function OrderDetailPage() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get(`/orders/${id}`).then(r => setOrder(r.data)).finally(() => setLoading(false));
  }, [id]);

  if (loading) return <PageLoader />;
  if (!order) return <div className="text-center py-20">Order not found</div>;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <Link to="/orders" className="flex items-center gap-2 text-gray-500 hover:text-orange-600 mb-6 text-sm">
        <ArrowLeft className="w-4 h-4" />Back to Orders
      </Link>
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-display text-2xl font-bold">Order #{order._id.slice(-8).toUpperCase()}</h1>
        <span className={`badge px-3 py-1 text-sm ${statusColors[order.status]}`}>{order.status}</span>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="card p-5">
            <h2 className="font-semibold mb-4">Items Ordered</h2>
            {order.orderItems.map(item => (
              <div key={item._id} className="flex items-center gap-3 py-3 border-b last:border-0">
                <img src={item.image} alt={item.name} className="w-14 h-14 object-cover rounded-lg" />
                <div className="flex-1"><p className="font-medium">{item.name}</p><p className="text-sm text-gray-500">Qty: {item.quantity}</p></div>
                <p className="font-bold">${(item.price * item.quantity).toFixed(2)}</p>
              </div>
            ))}
          </div>
          <div className="card p-5">
            <h2 className="font-semibold mb-3 flex items-center gap-2"><MapPin className="w-4 h-4 text-orange-600" />Shipping Address</h2>
            <p className="text-gray-700 text-sm">{order.shippingAddress.fullName}</p>
            <p className="text-gray-600 text-sm">{order.shippingAddress.address}</p>
            <p className="text-gray-600 text-sm">{order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zipCode}</p>
            <p className="text-gray-600 text-sm">{order.shippingAddress.country}</p>
          </div>
        </div>
        <div className="space-y-4">
          <div className="card p-5">
            <h2 className="font-semibold mb-3">Order Summary</h2>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between text-gray-600"><span>Subtotal</span><span>${order.itemsPrice.toFixed(2)}</span></div>
              <div className="flex justify-between text-gray-600"><span>Shipping</span><span>{order.shippingPrice === 0 ? 'FREE' : `$${order.shippingPrice.toFixed(2)}`}</span></div>
              <div className="flex justify-between text-gray-600"><span>Tax</span><span>${order.taxPrice.toFixed(2)}</span></div>
              <div className="border-t pt-2 flex justify-between font-bold"><span>Total</span><span>${order.totalPrice.toFixed(2)}</span></div>
            </div>
          </div>
          <div className="card p-5">
            <h2 className="font-semibold mb-3 flex items-center gap-2"><CreditCard className="w-4 h-4 text-orange-600" />Payment</h2>
            <p className="text-sm text-gray-700">{order.paymentMethod}</p>
            <p className={`text-sm mt-1 font-medium ${order.isPaid ? 'text-green-600' : 'text-red-500'}`}>{order.isPaid ? '✓ Paid' : '✗ Not Paid'}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
