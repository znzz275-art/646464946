import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { CheckCircle, Package, ArrowRight } from 'lucide-react';
import api from '../utils/api';
import { PageLoader } from '../components/common/Loader';

export default function OrderConfirmationPage() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get(`/orders/${id}`).then(r => setOrder(r.data)).finally(() => setLoading(false));
  }, [id]);

  if (loading) return <PageLoader />;
  if (!order) return <div className="text-center py-20">Order not found</div>;

  return (
    <div className="max-w-2xl mx-auto px-4 py-16 text-center">
      <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
        <CheckCircle className="w-10 h-10 text-green-600" />
      </div>
      <h1 className="font-display text-3xl font-bold text-gray-900 mb-3">Order Confirmed!</h1>
      <p className="text-gray-600 mb-2">Thank you for your purchase. We'll send you updates on your order.</p>
      <p className="text-sm text-gray-500 mb-8">Order ID: <span className="font-mono font-medium text-gray-700">{order._id}</span></p>

      <div className="card p-6 text-left mb-6">
        <h2 className="font-semibold mb-4">Order Details</h2>
        <div className="space-y-3">
          {order.orderItems.map(item => (
            <div key={item._id} className="flex items-center gap-3">
              <img src={item.image} alt={item.name} className="w-12 h-12 object-cover rounded-lg" />
              <div className="flex-1"><p className="font-medium text-sm">{item.name}</p><p className="text-xs text-gray-500">Qty: {item.quantity}</p></div>
              <p className="font-semibold">${(item.price * item.quantity).toFixed(2)}</p>
            </div>
          ))}
        </div>
        <div className="border-t mt-4 pt-4 space-y-1 text-sm">
          <div className="flex justify-between text-gray-600"><span>Subtotal</span><span>${order.itemsPrice.toFixed(2)}</span></div>
          <div className="flex justify-between text-gray-600"><span>Shipping</span><span>{order.shippingPrice === 0 ? 'FREE' : `$${order.shippingPrice.toFixed(2)}`}</span></div>
          <div className="flex justify-between font-bold text-base"><span>Total</span><span>${order.totalPrice.toFixed(2)}</span></div>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <Link to="/orders" className="btn-secondary flex-1 justify-center"><Package className="w-4 h-4" />View My Orders</Link>
        <Link to="/products" className="btn-primary flex-1 justify-center">Continue Shopping <ArrowRight className="w-4 h-4" /></Link>
      </div>
    </div>
  );
}
