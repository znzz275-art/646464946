import { Link } from 'react-router-dom';

export default function NotFoundPage() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 text-center">
      <div>
        <p className="text-9xl font-display font-bold text-orange-100">404</p>
        <h1 className="font-display text-3xl font-bold text-gray-900 -mt-4 mb-3">Page Not Found</h1>
        <p className="text-gray-500 mb-8">The page you're looking for doesn't exist.</p>
        <Link to="/" className="btn-primary inline-flex">Go Back Home</Link>
      </div>
    </div>
  );
}
