import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard, MapPin, Package } from 'lucide-react';
import { useCart } from '../context/CartContext';
import api from '../utils/api';
import toast from 'react-hot-toast';

export default function CheckoutPage() {
  const { items, total, clearCart } = useCart();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);

  const [shipping, setShipping] = useState({
    fullName: '', address: '', city: '', state: '',
    zipCode: '', country: 'USA', phone: '',
  });
  const [payment, setPayment] = useState('Credit Card');

  const shippingCost = total >= 50 ? 0 : 9.99;
  const tax = total * 0.1;
  const grand = total + shippingCost + tax;

  const placeOrder = async () => {
    setLoading(true);
    try {
      const { data } = await api.post('/orders', {
        orderItems: items.map(i => ({ product: i._id, name: i.name, image: i.images?.[0], price: i.price, quantity: i.quantity })),
        shippingAddress: shipping,
        paymentMethod: payment,
        itemsPrice: total,
        shippingPrice: shippingCost,
        taxPrice: tax,
        totalPrice: grand,
      });
      clearCart();
      navigate(`/order-confirmation/${data._id}`);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Order failed');
    } finally { setLoading(false); }
  };

  if (items.length === 0) { navigate('/cart'); return null; }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      <h1 className="font-display text-3xl font-bold text-gray-900 mb-8">Checkout</h1>

      {/* Steps */}
      <div className="flex items-center gap-4 mb-8">
        {[{ n: 1, label: 'Shipping', icon: MapPin }, { n: 2, label: 'Payment', icon: CreditCard }, { n: 3, label: 'Review', icon: Package }].map(({ n, label, icon: Icon }) => (
          <div key={n} className="flex items-center gap-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-colors ${step >= n ? 'bg-orange-600 text-white' : 'bg-gray-200 text-gray-500'}`}>
              {step > n ? '✓' : n}
            </div>
            <span className={`text-sm font-medium hidden sm:block ${step >= n ? 'text-gray-900' : 'text-gray-400'}`}>{label}</span>
            {n < 3 && <div className={`w-12 h-0.5 ${step > n ? 'bg-orange-600' : 'bg-gray-200'}`} />}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          {/* Step 1: Shipping */}
          {step === 1 && (
            <div className="card p-6">
              <h2 className="font-semibold text-lg mb-5 flex items-center gap-2"><MapPin className="w-5 h-5 text-orange-600" />Shipping Address</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {[['fullName', 'Full Name', 'col-span-2'], ['address', 'Street Address', 'col-span-2'],
                  ['city', 'City', ''], ['state', 'State', ''],
                  ['zipCode', 'ZIP Code', ''], ['country', 'Country', ''],
                  ['phone', 'Phone Number', 'col-span-2']
                ].map(([field, label, cls]) => (
                  <div key={field} className={cls || 'col-span-1'}>
                    <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
                    <input className="input-field" value={shipping[field]} onChange={e => setShipping(s => ({...s, [field]: e.target.value}))} required />
                  </div>
                ))}
              </div>
              <button onClick={() => {
                if (Object.values(shipping).some(v => !v)) { toast.error('Please fill all fields'); return; }
                setStep(2);
              }} className="btn-primary mt-6 ml-auto">Continue to Payment →</button>
            </div>
          )}

          {/* Step 2: Payment */}
          {step === 2 && (
            <div className="card p-6">
              <h2 className="font-semibold text-lg mb-5 flex items-center gap-2"><CreditCard className="w-5 h-5 text-orange-600" />Payment Method</h2>
              <div className="space-y-3">
                {['Credit Card', 'PayPal', 'Cash on Delivery'].map(m => (
                  <label key={m} className={`flex items-center gap-3 p-4 rounded-xl border-2 cursor-pointer transition-colors ${payment === m ? 'border-orange-600 bg-orange-50' : 'border-gray-200 hover:border-gray-300'}`}>
                    <input type="radio" name="payment" value={m} checked={payment === m} onChange={() => setPayment(m)} className="text-orange-600" />
                    <span className="font-medium">{m}</span>
                  </label>
                ))}
              </div>
              <div className="flex gap-3 mt-6">
                <button onClick={() => setStep(1)} className="btn-secondary flex-1">← Back</button>
                <button onClick={() => setStep(3)} className="btn-primary flex-1">Review Order →</button>
              </div>
            </div>
          )}

          {/* Step 3: Review */}
          {step === 3 && (
            <div className="card p-6">
              <h2 className="font-semibold text-lg mb-5 flex items-center gap-2"><Package className="w-5 h-5 text-orange-600" />Review Your Order</h2>
              <div className="mb-4">
                <h3 className="text-sm font-semibold text-gray-500 uppercase mb-2">Shipping to</h3>
                <p className="text-gray-700">{shipping.fullName}, {shipping.address}, {shipping.city}, {shipping.state} {shipping.zipCode}</p>
              </div>
              <div className="mb-6">
                <h3 className="text-sm font-semibold text-gray-500 uppercase mb-2">Payment via</h3>
                <p className="text-gray-700">{payment}</p>
              </div>
              <div className="space-y-3 mb-4">
                {items.map(i => (
                  <div key={i._id} className="flex items-center gap-3">
                    <img src={i.images?.[0]} alt={i.name} className="w-12 h-12 object-cover rounded-lg" />
                    <div className="flex-1"><p className="text-sm font-medium">{i.name}</p><p className="text-xs text-gray-500">Qty: {i.quantity}</p></div>
                    <p className="font-semibold text-sm">${(i.price * i.quantity).toFixed(2)}</p>
                  </div>
                ))}
              </div>
              <div className="flex gap-3 mt-6">
                <button onClick={() => setStep(2)} className="btn-secondary flex-1">← Back</button>
                <button onClick={placeOrder} disabled={loading} className="btn-primary flex-1">
                  {loading ? 'Placing Order...' : `Place Order • $${grand.toFixed(2)}`}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Summary */}
        <div className="card p-5 h-fit">
          <h3 className="font-semibold mb-4">Order Summary</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between text-gray-600"><span>Subtotal ({items.length} items)</span><span>${total.toFixed(2)}</span></div>
            <div className="flex justify-between text-gray-600"><span>Shipping</span><span className={shippingCost === 0 ? 'text-green-600' : ''}>{shippingCost === 0 ? 'FREE' : `$${shippingCost.toFixed(2)}`}</span></div>
            <div className="flex justify-between text-gray-600"><span>Tax</span><span>${tax.toFixed(2)}</span></div>
            <div className="border-t pt-2 flex justify-between font-bold text-base"><span>Total</span><span>${grand.toFixed(2)}</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}
