import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Save } from 'lucide-react';
import api from '../../utils/api';
import { PageLoader } from '../../components/common/Loader';
import toast from 'react-hot-toast';

const statusColors = {
  pending: 'bg-yellow-100 text-yellow-700', processing: 'bg-blue-100 text-blue-700',
  shipped: 'bg-purple-100 text-purple-700', delivered: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
};

export default function AdminOrderDetail() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get(`/orders/${id}`).then(r => { setOrder(r.data); setStatus(r.data.status); }).finally(() => setLoading(false));
  }, [id]);

  const updateStatus = async () => {
    setSaving(true);
    try {
      const { data } = await api.put(`/orders/${id}/status`, { status });
      setOrder(data);
      toast.success('Status updated!');
    } catch { toast.error('Update failed'); }
    finally { setSaving(false); }
  };

  if (loading) return <PageLoader />;
  if (!order) return <div>Order not found</div>;

  return (
    <div className="max-w-4xl">
      <div className="flex items-center gap-3 mb-6">
        <Link to="/admin/orders" className="p-2 hover:bg-gray-100 rounded-lg"><ArrowLeft className="w-4 h-4" /></Link>
        <div className="flex-1">
          <h1 className="font-display text-2xl font-bold">Order #{order._id.slice(-8).toUpperCase()}</h1>
          <p className="text-gray-500 text-sm">{new Date(order.createdAt).toLocaleString()}</p>
        </div>
        <span className={`badge capitalize px-3 py-1 text-sm ${statusColors[order.status]}`}>{order.status}</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <div className="card p-5">
            <h2 className="font-semibold mb-4">Order Items</h2>
            {order.orderItems.map(item => (
              <div key={item._id} className="flex items-center gap-3 py-3 border-b last:border-0">
                <img src={item.image} alt={item.name} className="w-14 h-14 object-cover rounded-lg" />
                <div className="flex-1"><p className="font-medium">{item.name}</p><p className="text-sm text-gray-500">Qty: {item.quantity} × ${item.price.toFixed(2)}</p></div>
                <p className="font-bold">${(item.price * item.quantity).toFixed(2)}</p>
              </div>
            ))}
            <div className="mt-4 space-y-1 text-sm">
              <div className="flex justify-between text-gray-600"><span>Items</span><span>${order.itemsPrice.toFixed(2)}</span></div>
              <div className="flex justify-between text-gray-600"><span>Shipping</span><span>{order.shippingPrice === 0 ? 'FREE' : `$${order.shippingPrice.toFixed(2)}`}</span></div>
              <div className="flex justify-between text-gray-600"><span>Tax</span><span>${order.taxPrice.toFixed(2)}</span></div>
              <div className="flex justify-between font-bold text-base border-t pt-2"><span>Total</span><span>${order.totalPrice.toFixed(2)}</span></div>
            </div>
          </div>

          <div className="card p-5">
            <h2 className="font-semibold mb-3">Shipping Address</h2>
            <p>{order.shippingAddress.fullName}</p>
            <p className="text-gray-600 text-sm">{order.shippingAddress.address}, {order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zipCode}, {order.shippingAddress.country}</p>
            <p className="text-gray-600 text-sm">{order.shippingAddress.phone}</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="card p-5">
            <h2 className="font-semibold mb-3">Customer</h2>
            <p className="font-medium">{order.user?.name}</p>
            <p className="text-gray-500 text-sm">{order.user?.email}</p>
          </div>
          <div className="card p-5">
            <h2 className="font-semibold mb-4">Update Status</h2>
            <select value={status} onChange={e => setStatus(e.target.value)} className="input-field text-sm mb-3">
              {['pending', 'processing', 'shipped', 'delivered', 'cancelled'].map(s => (
                <option key={s} value={s} className="capitalize">{s.charAt(0).toUpperCase() + s.slice(1)}</option>
              ))}
            </select>
            <button onClick={updateStatus} disabled={saving || status === order.status} className="btn-primary w-full text-sm py-2">
              <Save className="w-4 h-4" />{saving ? 'Saving...' : 'Update Status'}
            </button>
          </div>
          <div className="card p-5">
            <h2 className="font-semibold mb-3">Payment</h2>
            <p className="text-sm font-medium">{order.paymentMethod}</p>
            <p className={`text-sm mt-1 ${order.isPaid ? 'text-green-600' : 'text-red-500'}`}>{order.isPaid ? '✓ Paid' : '✗ Not Paid'}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
