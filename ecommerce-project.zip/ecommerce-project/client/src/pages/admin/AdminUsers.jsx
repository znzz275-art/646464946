import { useState, useEffect } from 'react';
import { Trash2, Search, Shield, User } from 'lucide-react';
import api from '../../utils/api';
import { PageLoader } from '../../components/common/Loader';
import Pagination from '../../components/common/Pagination';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState('');
  const [deleting, setDeleting] = useState(null);
  const { user: currentUser } = useAuth();

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/users?page=${page}&limit=15`);
      setUsers(data.users);
      setPages(data.pages);
      setTotal(data.total);
    } finally { setLoading(false); }
  };

  useEffect(() => { fetchUsers(); }, [page]);

  const deleteUser = async (id) => {
    if (id === currentUser._id) { toast.error("Can't delete your own account"); return; }
    if (!confirm('Delete this user? This action cannot be undone.')) return;
    setDeleting(id);
    try {
      await api.delete(`/users/${id}`);
      toast.success('User deleted');
      fetchUsers();
    } catch { toast.error('Delete failed'); }
    finally { setDeleting(null); }
  };

  const filtered = search ? users.filter(u =>
    u.name.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  ) : users;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display text-2xl font-bold">Users</h1>
          <p className="text-gray-500 text-sm">{total} total users</p>
        </div>
      </div>

      <div className="card overflow-hidden">
        <div className="p-4 border-b">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search users..."
              className="input-field pl-9 py-2 text-sm" />
          </div>
        </div>

        {loading ? <div className="p-8"><PageLoader /></div> : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b">
                <tr>{['User', 'Email', 'Role', 'Joined', 'Actions'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>
                ))}</tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filtered.map(u => (
                  <tr key={u._id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${u.role === 'admin' ? 'bg-orange-100' : 'bg-gray-100'}`}>
                          {u.role === 'admin' ? <Shield className="w-4 h-4 text-orange-600" /> : <span className="text-gray-600 font-semibold text-sm">{u.name[0]}</span>}
                        </div>
                        <span className="font-medium text-gray-900">{u.name}</span>
                        {u._id === currentUser._id && <span className="badge bg-orange-100 text-orange-600 text-xs">You</span>}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-gray-600">{u.email}</td>
                    <td className="px-4 py-3">
                      <span className={`badge text-xs capitalize ${u.role === 'admin' ? 'bg-orange-100 text-orange-700' : 'bg-gray-100 text-gray-600'}`}>{u.role}</span>
                    </td>
                    <td className="px-4 py-3 text-gray-500">{new Date(u.createdAt).toLocaleDateString()}</td>
                    <td className="px-4 py-3">
                      <button onClick={() => deleteUser(u._id)} disabled={deleting === u._id || u._id === currentUser._id}
                        className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-40 disabled:cursor-not-allowed">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filtered.length === 0 && <div className="text-center py-12 text-gray-500">No users found</div>}
          </div>
        )}
        <div className="p-4 border-t">
          <Pagination page={page} pages={pages} onPageChange={setPage} />
        </div>
      </div>
    </div>
  );
}
