import { useState, useEffect } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { Upload, X, ArrowLeft, Plus } from 'lucide-react';
import api from '../../utils/api';
import { PageLoader } from '../../components/common/Loader';
import toast from 'react-hot-toast';

export default function AdminProductForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = !!id;

  const [form, setForm] = useState({
    name: '', description: '', price: '', originalPrice: '',
    category: '', brand: '', stock: '', featured: false,
    isActive: true, tags: '',
  });
  const [images, setImages] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading] = useState(isEdit);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (isEdit) {
      api.get(`/products/${id}`).then(r => {
        const p = r.data;
        setForm({
          name: p.name, description: p.description, price: p.price,
          originalPrice: p.originalPrice || '', category: p.category,
          brand: p.brand || '', stock: p.stock, featured: p.featured,
          isActive: p.isActive, tags: p.tags?.join(', ') || '',
        });
        setImages(p.images || []);
      }).finally(() => setLoading(false));
    }
  }, [id]);

  const uploadImages = async (files) => {
    const formData = new FormData();
    Array.from(files).forEach(f => formData.append('images', f));
    setUploading(true);
    try {
      const { data } = await api.post('/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      setImages(prev => [...prev, ...data.urls]);
      toast.success('Images uploaded!');
    } catch { toast.error('Upload failed'); }
    finally { setUploading(false); }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        ...form,
        price: Number(form.price),
        originalPrice: Number(form.originalPrice) || 0,
        stock: Number(form.stock),
        images,
        tags: form.tags.split(',').map(t => t.trim()).filter(Boolean),
      };
      if (isEdit) {
        await api.put(`/products/${id}`, payload);
        toast.success('Product updated!');
      } else {
        await api.post('/products', payload);
        toast.success('Product created!');
      }
      navigate('/admin/products');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Save failed');
    } finally { setSaving(false); }
  };

  if (loading) return <PageLoader />;

  return (
    <div className="max-w-3xl">
      <div className="flex items-center gap-3 mb-6">
        <Link to="/admin/products" className="p-2 hover:bg-gray-100 rounded-lg">
          <ArrowLeft className="w-4 h-4" />
        </Link>
        <h1 className="font-display text-2xl font-bold">{isEdit ? 'Edit Product' : 'Add Product'}</h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="card p-6">
          <h2 className="font-semibold mb-4">Basic Information</h2>
          <div className="grid grid-cols-1 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Product Name *</label>
              <input className="input-field" value={form.name} onChange={e => setForm(f => ({...f, name: e.target.value}))} required />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Description *</label>
              <textarea rows={4} className="input-field resize-none" value={form.description}
                onChange={e => setForm(f => ({...f, description: e.target.value}))} required />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Category *</label>
                <input className="input-field" value={form.category} onChange={e => setForm(f => ({...f, category: e.target.value}))} required />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Brand</label>
                <input className="input-field" value={form.brand} onChange={e => setForm(f => ({...f, brand: e.target.value}))} />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Price *</label>
                <input type="number" step="0.01" min="0" className="input-field" value={form.price}
                  onChange={e => setForm(f => ({...f, price: e.target.value}))} required />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Original Price</label>
                <input type="number" step="0.01" min="0" className="input-field" value={form.originalPrice}
                  onChange={e => setForm(f => ({...f, originalPrice: e.target.value}))} />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Stock *</label>
                <input type="number" min="0" className="input-field" value={form.stock}
                  onChange={e => setForm(f => ({...f, stock: e.target.value}))} required />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Tags (comma-separated)</label>
                <input className="input-field" value={form.tags} onChange={e => setForm(f => ({...f, tags: e.target.value}))} placeholder="electronics, wireless" />
              </div>
            </div>
            <div className="flex items-center gap-6">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={form.featured} onChange={e => setForm(f => ({...f, featured: e.target.checked}))} className="w-4 h-4 text-orange-600 rounded" />
                <span className="text-sm font-medium">Featured Product</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={form.isActive} onChange={e => setForm(f => ({...f, isActive: e.target.checked}))} className="w-4 h-4 text-orange-600 rounded" />
                <span className="text-sm font-medium">Active (visible to customers)</span>
              </label>
            </div>
          </div>
        </div>

        {/* Images */}
        <div className="card p-6">
          <h2 className="font-semibold mb-4">Product Images</h2>
          <div className="grid grid-cols-4 gap-3 mb-4">
            {images.map((img, i) => (
              <div key={i} className="relative aspect-square rounded-lg overflow-hidden border border-gray-200 group">
                <img src={img} alt={`Image ${i+1}`} className="w-full h-full object-cover" />
                <button type="button" onClick={() => setImages(prev => prev.filter((_, idx) => idx !== i))}
                  className="absolute top-1 right-1 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <X className="w-3 h-3" />
                </button>
                {i === 0 && <span className="absolute bottom-1 left-1 bg-orange-600 text-white text-xs px-1.5 py-0.5 rounded">Main</span>}
              </div>
            ))}
            <label className="aspect-square rounded-lg border-2 border-dashed border-gray-200 hover:border-orange-400 flex flex-col items-center justify-center cursor-pointer transition-colors">
              {uploading ? <div className="w-6 h-6 border-2 border-orange-600 border-t-transparent rounded-full animate-spin" />
                : <><Upload className="w-6 h-6 text-gray-400 mb-1" /><span className="text-xs text-gray-400">Upload</span></>}
              <input type="file" multiple accept="image/*" className="hidden" onChange={e => uploadImages(e.target.files)} />
            </label>
          </div>
          <p className="text-xs text-gray-400">You can also enter image URLs directly:</p>
          <div className="flex gap-2 mt-2">
            <input id="urlInput" className="input-field text-sm py-2" placeholder="https://example.com/image.jpg" />
            <button type="button" onClick={() => {
              const url = document.getElementById('urlInput').value.trim();
              if (url) { setImages(prev => [...prev, url]); document.getElementById('urlInput').value = ''; }
            }} className="btn-secondary py-2 px-4 text-sm flex-shrink-0"><Plus className="w-4 h-4" /></button>
          </div>
        </div>

        <div className="flex gap-3">
          <Link to="/admin/products" className="btn-secondary flex-1 justify-center">Cancel</Link>
          <button type="submit" disabled={saving} className="btn-primary flex-1 justify-center">
            {saving ? 'Saving...' : isEdit ? 'Update Product' : 'Create Product'}
          </button>
        </div>
      </form>
    </div>
  );
}
