import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Users, Package, ShoppingBag, DollarSign, TrendingUp, ArrowRight } from 'lucide-react';
import api from '../../utils/api';
import { PageLoader } from '../../components/common/Loader';

const statusColors = {
  pending: 'bg-yellow-100 text-yellow-700', processing: 'bg-blue-100 text-blue-700',
  shipped: 'bg-purple-100 text-purple-700', delivered: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
};

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/orders/admin/stats').then(r => setStats(r.data)).finally(() => setLoading(false));
  }, []);

  if (loading) return <PageLoader />;

  const cards = [
    { label: 'Total Revenue', value: `$${stats.totalRevenue.toFixed(2)}`, icon: DollarSign, color: 'bg-green-50 text-green-600', change: '+12%' },
    { label: 'Total Orders', value: stats.totalOrders, icon: ShoppingBag, color: 'bg-blue-50 text-blue-600', change: '+8%' },
    { label: 'Total Products', value: stats.totalProducts, icon: Package, color: 'bg-orange-50 text-orange-600', change: '+3%' },
    { label: 'Total Users', value: stats.totalUsers, icon: Users, color: 'bg-purple-50 text-purple-600', change: '+5%' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-500 text-sm mt-1">Welcome back! Here's what's happening.</p>
        </div>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map(({ label, value, icon: Icon, color, change }) => (
          <div key={label} className="card p-5">
            <div className="flex items-center justify-between mb-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${color}`}>
                <Icon className="w-5 h-5" />
              </div>
              <span className="text-xs font-medium text-green-600 bg-green-50 px-2 py-0.5 rounded-full">{change}</span>
            </div>
            <p className="text-2xl font-bold text-gray-900">{value}</p>
            <p className="text-gray-500 text-sm">{label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent orders */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">Recent Orders</h2>
            <Link to="/admin/orders" className="text-sm text-orange-600 hover:text-orange-700 flex items-center gap-1">
              View all <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="space-y-3">
            {stats.recentOrders?.map(order => (
              <Link key={order._id} to={`/admin/orders/${order._id}`} className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition-colors">
                <div>
                  <p className="text-sm font-medium text-gray-900">{order.user?.name || 'Unknown'}</p>
                  <p className="text-xs text-gray-500">{new Date(order.createdAt).toLocaleDateString()}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold">${order.totalPrice.toFixed(2)}</p>
                  <span className={`badge text-xs ${statusColors[order.status]}`}>{order.status}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Orders by status */}
        <div className="card p-5">
          <h2 className="font-semibold mb-4">Orders by Status</h2>
          <div className="space-y-3">
            {stats.ordersByStatus?.map(({ _id: status, count }) => (
              <div key={status} className="flex items-center gap-3">
                <span className={`badge capitalize min-w-20 justify-center ${statusColors[status]}`}>{status}</span>
                <div className="flex-1 bg-gray-100 rounded-full h-2 overflow-hidden">
                  <div className="h-full bg-orange-500 rounded-full" style={{ width: `${(count / stats.totalOrders) * 100}%` }} />
                </div>
                <span className="text-sm font-medium w-8 text-right">{count}</span>
              </div>
            ))}
          </div>

          <div className="mt-6">
            <h3 className="font-medium text-sm text-gray-500 mb-3">Revenue by Month</h3>
            <div className="space-y-2">
              {stats.revenueByMonth?.slice(0, 4).map(({ _id, revenue, orders }) => (
                <div key={`${_id.year}-${_id.month}`} className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">{new Date(_id.year, _id.month - 1).toLocaleString('default', { month: 'short', year: 'numeric' })}</span>
                  <div className="flex items-center gap-4">
                    <span className="text-gray-500">{orders} orders</span>
                    <span className="font-semibold">${revenue.toFixed(0)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
