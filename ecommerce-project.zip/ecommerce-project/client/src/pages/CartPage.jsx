import { Link } from 'react-router-dom';
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight } from 'lucide-react';
import { useCart } from '../context/CartContext';

export default function CartPage() {
  const { items, removeFromCart, updateQuantity, total } = useCart();

  if (items.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <ShoppingBag className="w-20 h-20 text-gray-200 mx-auto mb-6" />
        <h2 className="font-display text-3xl font-bold text-gray-900 mb-3">Your cart is empty</h2>
        <p className="text-gray-500 mb-8">Looks like you haven't added anything to your cart yet.</p>
        <Link to="/products" className="btn-primary inline-flex">Start Shopping <ArrowRight className="w-5 h-5" /></Link>
      </div>
    );
  }

  const shipping = total >= 50 ? 0 : 9.99;
  const tax = total * 0.1;
  const grandTotal = total + shipping + tax;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      <h1 className="font-display text-3xl font-bold text-gray-900 mb-8">Shopping Cart ({items.length})</h1>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Items */}
        <div className="lg:col-span-2 space-y-4">
          {items.map(item => (
            <div key={item._id} className="card p-4 flex gap-4">
              <Link to={`/products/${item._id}`}>
                <img src={item.images?.[0] || 'https://via.placeholder.com/100'} alt={item.name}
                  className="w-24 h-24 object-cover rounded-xl flex-shrink-0" />
              </Link>
              <div className="flex-1 min-w-0">
                <Link to={`/products/${item._id}`} className="font-semibold text-gray-900 hover:text-orange-600 line-clamp-1">{item.name}</Link>
                <p className="text-orange-600 font-bold mt-1">${item.price.toFixed(2)}</p>
                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center border border-gray-200 rounded-lg">
                    <button onClick={() => updateQuantity(item._id, item.quantity - 1)} className="w-8 h-8 flex items-center justify-center hover:bg-gray-50 rounded-l-lg">
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-10 text-center text-sm font-semibold">{item.quantity}</span>
                    <button onClick={() => updateQuantity(item._id, item.quantity + 1)} className="w-8 h-8 flex items-center justify-center hover:bg-gray-50 rounded-r-lg">
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="font-bold text-gray-900">${(item.price * item.quantity).toFixed(2)}</span>
                    <button onClick={() => removeFromCart(item._id)} className="text-red-400 hover:text-red-600 transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Summary */}
        <div className="card p-6 h-fit">
          <h2 className="font-semibold text-lg mb-4">Order Summary</h2>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between"><span className="text-gray-600">Subtotal</span><span>${total.toFixed(2)}</span></div>
            <div className="flex justify-between">
              <span className="text-gray-600">Shipping</span>
              <span className={shipping === 0 ? 'text-green-600 font-medium' : ''}>{shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`}</span>
            </div>
            <div className="flex justify-between"><span className="text-gray-600">Tax (10%)</span><span>${tax.toFixed(2)}</span></div>
            <div className="border-t pt-3 flex justify-between font-bold text-base">
              <span>Total</span><span>${grandTotal.toFixed(2)}</span>
            </div>
          </div>
          {shipping > 0 && (
            <p className="text-xs text-orange-600 mt-3 bg-orange-50 px-3 py-2 rounded-lg">
              Add ${(50 - total).toFixed(2)} more for free shipping!
            </p>
          )}
          <Link to="/checkout" className="btn-primary w-full mt-5">
            Proceed to Checkout <ArrowRight className="w-4 h-4" />
          </Link>
          <Link to="/products" className="btn-ghost w-full mt-2 text-sm justify-center">Continue Shopping</Link>
        </div>
      </div>
    </div>
  );
}
