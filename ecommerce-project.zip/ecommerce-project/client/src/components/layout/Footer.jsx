import { Link } from 'react-router-dom';
import { Instagram, Twitter, Facebook, Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-orange-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">S</span>
              </div>
              <span className="font-display font-bold text-xl text-white">ShopLux</span>
            </div>
            <p className="text-sm leading-relaxed">Premium products curated for the discerning shopper. Quality you can trust, style you'll love.</p>
            <div className="flex gap-3 mt-4">
              {[Instagram, Twitter, Facebook].map((Icon, i) => (
                <a key={i} href="#" className="w-8 h-8 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-orange-600 transition-colors">
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-4">Shop</h4>
            <ul className="space-y-2 text-sm">
              {['All Products', 'New Arrivals', 'Best Sellers', 'Sale'].map(item => (
                <li key={item}><Link to="/products" className="hover:text-orange-400 transition-colors">{item}</Link></li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-4">Account</h4>
            <ul className="space-y-2 text-sm">
              {[['Profile', '/profile'], ['My Orders', '/orders'], ['Sign In', '/login'], ['Register', '/register']].map(([label, href]) => (
                <li key={label}><Link to={href} className="hover:text-orange-400 transition-colors">{label}</Link></li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-4">Contact</h4>
            <div className="flex items-center gap-2 text-sm">
              <Mail className="w-4 h-4 text-orange-500" />
              <span>hello@shoplux.com</span>
            </div>
            <p className="text-xs text-gray-500 mt-6">© {new Date().getFullYear()} ShopLux. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
