import { Link } from 'react-router-dom';
import { ShoppingCart, Star, Heart } from 'lucide-react';
import { useCart } from '../../context/CartContext';

export default function ProductCard({ product }) {
  const { addToCart } = useCart();
  const discount = product.originalPrice > product.price
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <div className="card group hover:shadow-md transition-all duration-300 hover:-translate-y-1">
      <div className="relative overflow-hidden aspect-square bg-gray-100">
        <Link to={`/products/${product._id}`}>
          <img
            src={product.images?.[0] || 'https://via.placeholder.com/400x400?text=No+Image'}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        </Link>
        {discount > 0 && (
          <span className="absolute top-2 left-2 badge bg-red-500 text-white">-{discount}%</span>
        )}
        {product.stock === 0 && (
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
            <span className="bg-white text-gray-900 text-sm font-semibold px-3 py-1 rounded-full">Out of Stock</span>
          </div>
        )}
        {product.featured && (
          <span className="absolute top-2 right-2 badge bg-orange-600 text-white">Featured</span>
        )}
      </div>
      <div className="p-4">
        <p className="text-xs text-orange-600 font-medium mb-1 uppercase tracking-wide">{product.category}</p>
        <Link to={`/products/${product._id}`}>
          <h3 className="font-semibold text-gray-900 mb-1 line-clamp-1 hover:text-orange-600 transition-colors">{product.name}</h3>
        </Link>
        <div className="flex items-center gap-1 mb-3">
          {[1,2,3,4,5].map(star => (
            <Star key={star} className={`w-3 h-3 ${star <= Math.round(product.rating) ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`} />
          ))}
          <span className="text-xs text-gray-500 ml-1">({product.numReviews})</span>
        </div>
        <div className="flex items-center justify-between">
          <div>
            <span className="font-bold text-gray-900">${product.price.toFixed(2)}</span>
            {product.originalPrice > product.price && (
              <span className="text-gray-400 text-sm line-through ml-2">${product.originalPrice.toFixed(2)}</span>
            )}
          </div>
          <button
            onClick={() => addToCart(product)}
            disabled={product.stock === 0}
            className="w-9 h-9 bg-orange-600 hover:bg-orange-700 disabled:bg-gray-300 text-white rounded-lg flex items-center justify-center transition-colors"
          >
            <ShoppingCart className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
