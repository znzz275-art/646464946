import { ChevronLeft, ChevronRight } from 'lucide-react';

export default function Pagination({ page, pages, onPageChange }) {
  if (pages <= 1) return null;

  const getPageNumbers = () => {
    const nums = [];
    const delta = 2;
    for (let i = Math.max(2, page - delta); i <= Math.min(pages - 1, page + delta); i++) nums.push(i);
    if (page - delta > 2) nums.unshift('...');
    if (page + delta < pages - 1) nums.push('...');
    nums.unshift(1);
    if (pages > 1) nums.push(pages);
    return [...new Set(nums)];
  };

  return (
    <div className="flex items-center justify-center gap-1 mt-8">
      <button onClick={() => onPageChange(page - 1)} disabled={page === 1}
        className="w-9 h-9 flex items-center justify-center rounded-lg border border-gray-200 hover:border-orange-600 hover:text-orange-600 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
        <ChevronLeft className="w-4 h-4" />
      </button>
      {getPageNumbers().map((p, i) => (
        <button key={i} onClick={() => typeof p === 'number' && onPageChange(p)} disabled={p === '...'}
          className={`w-9 h-9 flex items-center justify-center rounded-lg text-sm font-medium transition-colors ${
            p === page ? 'bg-orange-600 text-white border-orange-600' : p === '...' ? 'cursor-default text-gray-400' : 'border border-gray-200 hover:border-orange-600 hover:text-orange-600'
          }`}>
          {p}
        </button>
      ))}
      <button onClick={() => onPageChange(page + 1)} disabled={page === pages}
        className="w-9 h-9 flex items-center justify-center rounded-lg border border-gray-200 hover:border-orange-600 hover:text-orange-600 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
        <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
}
